(* Translate a Copland phrase into an S-expression *)

open Sexpr
open Filter
open Copland

let dirs = function
  | Dup -> [sym "dup"; sym "dup"]
  | Lft -> [sym "dup"; sym "nil"]
  | Rht -> [sym "nil"; sym "dup"]
  | Nil -> [sym "nil"; sym "nil"]

let order = function
  | Seq d -> lst (sym "seq" :: dirs d)
  | Par d -> lst (sym "par" :: dirs d)

let rec phrase = function
  | NUL -> sym "null"
  | CPY -> sym "copy"
  | MEAS (asp, q, target) ->
     lst [sym "msp"; sym asp; sym q; sym target]
  | SIG -> sym "sign"
  | HSH -> sym "hash"
  | AT (p, t) -> lst [sym "at"; sym p; phrase t]
  | LN (t1, t2) ->
     let x1 = phrase t1 in
     let x2 = phrase t2 in
     lst [sym "pipe"; x1; x2]
  | BR (ord, t1, t2) ->
     let x0 = order ord in
     let x1 = phrase t1 in
     let x2 = phrase t2 in
     lst [sym "branch"; x0; x1; x2]

let copland2sexpr (plc, nonce, t) =
  let x = phrase t in
  match nonce with
  | None ->
      lst [sym "copland";
           lst [sym "origin"; sym plc];
           x]
  | Some nonce ->
      lst [sym "copland";
           lst [sym "origin"; sym plc];
           lst [sym "nonce"; sym nonce];
           x]

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let x = copland2sexpr t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  print_sexpr o x;
  close_out o

let () =
  filter "0.1" go
