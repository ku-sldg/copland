(* The coplandpp program *)
