(* Translate a Copland phrase into dot showing its abstract syntax*)

open Printf
open Filter
open Copland

let order = function
  | Seq Dup -> "+<+"
  | Seq Lft -> "+<-"
  | Seq Rht -> "-<+"
  | Seq Nil -> "-<-"
  | Par Dup -> "+~+"
  | Par Lft -> "+~-"
  | Par Rht -> "-~+"
  | Par Nil -> "-~-"

let rec dot o i = function
  | NUL ->
     fprintf o "  n%d [label=\"{}\"]\n" i;
     i + 1
  | CPY ->
     fprintf o "  n%d [label=\"_\"]\n" i;
     i + 1
  | MEAS (asp, q, target) ->
     fprintf o "  n%d [label=\"%s %s %s\"]\n" i asp q target;
     i + 1
  | SIG ->
     fprintf o "  n%d [label=\"!\"]\n" i;
     i + 1
  | HSH ->
     fprintf o "  n%d [label=\"#\"]\n" i;
     i + 1
  | AT (p, t) ->
     let i = dot o i t in
     fprintf o "  n%d [label=\"@%s\"]\n" i p;
     fprintf o "  n%d -> n%d\n" i (i - 1);
     i + 1
  | LN (t1, t2) ->
     let j = dot o i t1 in
     let k = dot o j t2 in
     fprintf o "  n%d [label=\"->\"]\n" k;
     fprintf o "  n%d -> n%d\n" k (j - 1);
     fprintf o "  n%d -> n%d\n" k (k - 1);
     k + 1
  | BR (ord, t1, t2) ->
     let j = dot o i t1 in
     let k = dot o j t2 in
     fprintf o "  n%d [label=\"%s\"]\n" k (order ord);
     fprintf o "  n%d -> n%d\n" k (j - 1);
     fprintf o "  n%d -> n%d\n" k (k - 1);
     k + 1

let print_dot o (_, _, t) =
  fprintf o "digraph AST {\n";
  let _ = dot o 0 t in
  fprintf o "}\n"

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  print_dot o t;
  close_out o

let () =
  filter "0.1" go
