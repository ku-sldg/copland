type term
val vr : string -> term         (* Uppercase string *)
val cn : string -> term         (* Lowercase string *)
val fn : string -> term list -> term (* Lowercase string *)
type atom
val pred : string -> term list -> atom (* Lowercase string *)
val eq : term -> term -> atom
type geolog = atom list * atom list list
val print_form : Format.formatter -> geolog -> unit
val sexpr_print_form : Format.formatter -> geolog -> unit
