(* Geolog abstract syntax and two pretty printers *)

open Format
open Sexpr

let is_uppercase str =
  String.length str > 0 &&
    let ch = Char.code @@ str.[0] in
    ch >= 65 && ch <= 90

let is_lowercase str =
  String.length str > 0 &&
    let ch = Char.code @@ str.[0] in
    ch >= 97 && ch <= 122

type term =
  | Var of string
  | App of string * term list

let vr str =
  if is_uppercase str then
    Var str
  else
    failwith ("Expecting a variable but got " ^ str)

let cn str =
  if is_lowercase str then
    App (str, [])
  else
    failwith ("Expecting a constant but got " ^ str)

let fn str args =
  if is_lowercase str then
    App (str, args)
  else
    failwith ("Expecting a function symbol but got " ^ str)

type atom =
  | Pred of string * term list
  | Eq of term * term

let pred str args =
  if is_lowercase str then
    Pred (str, args)
  else
    failwith ("Expecting a predicate symbol but got " ^ str)

let eq t1 t2 = Eq (t1, t2)

type geolog = atom list * atom list list

(* Pretty printer using Chase syntax *)

let print_arg pp f x =
  pp_print_string f "(";
  pp f x;
  pp_print_string f ")"

let print_args pp f xs =
  pp_print_string f "(";
  pp_open_box f 0;
  let sep f () =
    pp_print_string f ",";
    pp_print_space f () in
  pp_print_list ~pp_sep:sep pp f xs;
  pp_print_string f ")";
  pp_close_box f ()

let rec print_term f = function
  | Var s -> pp_print_string f s
  | App (s, []) -> pp_print_string f s
  | App (s, [x]) ->
     pp_print_string f s;
     print_arg print_term f x
  | App (s, xs) ->
     pp_print_string f s;
     print_args print_term f xs

let print_atom f = function
  | Pred (s, []) ->
     pp_print_string f s
  | Pred (s, [x]) ->
     pp_print_string f (s);
     print_arg (print_term) f x
  | Pred (s, xs) ->
     pp_print_string f s;
     print_args (print_term) f xs
  | Eq (x, y) ->
     pp_open_box f 2;
     print_term f x;
     pp_print_space f ();
     pp_print_string f "= ";
     print_term f y;
     pp_close_box f ()

let print_conj f = function
  | [] ->
     pp_print_string f "true"
  | [x] ->
     print_atom f x
  | xs ->
     pp_open_box f 2;
     let sep f () =
       pp_print_space f ();
       pp_print_string f "& " in
     pp_print_list ~pp_sep:sep print_atom f xs;
     pp_close_box f ()

let print_disj f = function
  | [] ->
     pp_print_string f "false"
  | [x] ->
     print_conj f x
  | xs ->
     pp_open_box f 2;
     let sep f () =
       pp_print_space f ();
       pp_print_string f "| " in
     pp_print_list ~pp_sep:sep print_conj f xs;
     pp_close_box f ()

(* Printer for a formula *)
let print_form f = function
  | [], [] ->                   (* A trick for forcing a newline *)
     pp_print_newline f ()
  | [], disj ->
     print_disj f disj;
     pp_print_string f ".";
     pp_print_newline f ()
  | conj, disj ->
     pp_open_box f 2;
     print_conj f conj;
     pp_print_space f ();
     pp_print_string f "=> ";
     print_disj f disj;
     pp_print_string f ".";
     pp_print_newline f ()

(* Pretty printer using S-expressions *)

let rec sexpr_term = function
  | Var s -> sym s
  | App (s, xs) -> lst (sym s :: List.map sexpr_term xs)

let sexpr_atom = function
  | Pred (s, xs) -> lst (sym s :: List.map sexpr_term xs)
  | Eq (x, y) -> lst [sym "="; sexpr_term x; sexpr_term y]

let sexpr_conj = function
  | [] -> sym "true"
  | [x] -> sexpr_atom x
  | xs -> lst (sym "and" :: List.map sexpr_atom xs)

let sexpr_disj = function
  | [] -> sym "false"
  | [x] -> sexpr_conj x
  | xs -> lst (sym "or" :: List.map sexpr_conj xs)

let sexpr_form = function
  | [], disj -> sexpr_disj disj
  | conj, disj ->
     lst [sym "=>"; sexpr_conj conj; sexpr_disj disj]

let sexpr_print_form f g =
  sexpr_printer f (sexpr_form g);
  pp_print_newline f ()
