(* Generates a shell script that generates XHTML output for each model
   found by Chase.  A typical usage is:

   $ chase -tcs | sexprsplit | /bin/sh *)

open Format
open Sexpr
open Margin

let prelude =
  "#! /bin/sh\n\
   \n\
   # Strip the first 3 lines of text out of an SVG document produced by dot.\n\
   stripsvg () {\n\
   \    sed '\n\
   /^<\\?xml/ {\n\
   \  N\n\
   \  N\n\
   \  d\n\
   }'\n\
   }\n\
   \n\
   model=0\n\
   \n\
   # Print one model\n\
   sexpr () {\n\
   \    echo\n\
   \    model=$(($model + 1))\n\
   \    echo \"<h3>Model $model</h3>\"\n\
   \    echo\n\
   \    prec -c | tred | dot -Tsvg | stripsvg\n\
   }\n\
   \n"

let run margin o xs =
  output_string o prelude;
  let f = formatter_of_out_channel o in (* Grab formatter *)
  if margin > 0 then
    pp_set_margin f margin;     (* Set margin *)
  let pp x =
    begin
      pp_print_string f "sexpr <<\\EOF";
      pp_print_newline f ();
      sexpr_printer f x;
      pp_print_newline f ();
      pp_print_string f "EOF";
      pp_print_newline f ();
      pp_print_newline f ()
    end
  in
  List.iter pp xs

let read_sexprs ch =
  let rec loop xs =
    try
      let x = read_sexpr ch in
      loop (x :: xs)
    with
    | End_of_file ->
	List.rev xs in
  loop []

let go margin f i ofile =
  let lb = read_lexbuf f i in
  let xs = read_sexprs lb in
  close_in i;
  let o =
    if ofile = "" then
      stdout
    else
      open_out ofile in
  run margin o xs

let () =
  filter "0.2" go
