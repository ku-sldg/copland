# Copland Collection

This project contains a collection of programs and scripts for
analyzing and displaying Copland phrases.

## Installing the Sources

This software uses OCaml, opam, dune, and Graphviz.  See
<http://ocaml.org> for OCaml installation instructions.  See
<https://graphviz.org/> for Graphviz installation instructions.  You
can use brew to install graphviz on MacOS.  Install dune and chase with:

    $ opam install dune chase

Install the programs with:

    $ dune build
    $ dune install

## Copland Syntax

A symbol is a letter optionally followed by letters, digits,
and underscores.  The syntax of a Copland phrase is

```
COPLAND ::= * PLACE NONCE : PHRASE | PHRASE

PLACE   ::= SYMBOL | DIGITS

NONCE   ::= | , SYMBOL

PHRASE  ::= SYMBOL PLACE SYMBOL      -- Measurement (probe place target)
         |  {}                       -- Null
         |  _                        -- Copy
         |  !                        -- Signature
         |  #                        -- Hash
         |  @ PLACE PHRASE           -- At place
         |  @ PLACE [ PHRASE ]       -- At place with brackets
         |  PHRASE -> PHRASE         -- Linear sequencing
         |  PHRASE BRANCH PHRASE     -- Sequential and parallel branching
         |  ( PHRASE )

BRANCH  ::= -<- | +<- | -<+ | +<+    -- Sequential
         |  -~- | +~- | -~+ | +~+    -- Parallel
```

The initial place `P` is specified using `*P:`, and this place
defaults to `p0` with left unspecified.  An initial nonce `n` can
optionally specified with `*P, n:`.

The branching operator +O+ sends the evidence both left and right, +O-
sends the evidence left, -O+ sends the evidence right, and -O- sends
the empty evidence in both directions.

The @ operator has the lowest precedence, the branching operator is
non-associative and has medium precedence, and linear sequencing
operator is right associative and has the highest precedence.  Thus

    *p0: @p1 kim p2 ker -> ! -<- @p2 (vc p2 sys) -> !

Is equivalent to

    *p0: @p1 (((kim p2 ker) -> !) -<- (@p2 ((vc p2 sys) -> !)))

Notice that the largest Copland phrase that follows an @ operator is
the one that is associated with it when brackets are omitted.

When a place is a sequence of digits, it is equivalent to the symbol
that results from adding the letter `p` to the beginning of the digits.

The comment character is percent.

## Most Used Script: `copland2xhtml`

```
$ copland2xhtml -h
Analyze a Copland phrase
Usage: copland2xhtml [-e] COPLAND-FILE > XHTML-FILE
With the -e option, evidence is added to graphs
```

## Content

The important directories are:

 * copland -- a library for reading and printing Copland phrases.

 * copland2ast -- a program that displays the abstract syntax of a
   Copland phrase.  Requires Graphviz.

 * copland2dot -- a program that displays the event semantics of a
   Copland phrase using Graphviz.

 * copland2evidot -- a program that displays the event semantics of a
   Copland phrase using Graphviz that adds evidence to graphs.

 * copland2flowdot -- a program that displays the data flow graph and
   tamper strategies of a Copland phrase using Graphviz.

 * copland2chase -- a program that produces the event semantics of a
   Copland phrase as Chase input (defunct).

 * coplandval2chase -- a program that produces the event semantics of a
   Copland phrase as Chase input using evidence values instead of types.

 * copland2measchase -- a program that produces the measurement event
   semantics of a Copland phrase as Chase input (defunct).

 * coplandval2measchase -- a program that produces the measurement
   event semantics of a Copland phrase as Chase input using evidence
   values instead of types.

 * copland2distinct -- a program that produces axioms that ensure
   places, probes, and targets in Copland phrase remain distinct.

 * coplandpp -- a program that pretty prints a Copland phrase.

 * coplandevi -- a program that pretty prints a Copland phrase's evidence.

 * coplandsigncom -- a simple program that adds signatures to a
   Copland phrase.

 * coplandsignall -- a program that adds signatures to a Copland
   phrase and avoids signing empty evidence.

 * copland2sexpr -- a program that prints a Copland phrase as an
   S-expression.

 * copland2tmpr -- a program that outputs the minimal tamper
   strategies of a Copland phrase as Chase input.

 * copland2evtpos -- a program that assigns unique positions to the
   events of a Copland phrase.

 * copland2evipos -- a program that assigns unique positions to the
   events of a Copland phrase in a different way than copland2evtpos.

 * examples -- examples of the use of copland2xhtml and coplandvalchase.

 * events -- a library for Copland evidence values and their events.

 * filter -- a library for command-line processing.

 * flow -- a library for Copland data flow graphs.

 * geolog -- a library for pretty printing Geolog axioms.

 * include -- contains Makefile rules for Chase.

 * margin -- a library for command-line processing with an option for
   setting margins.

 * prec -- a program for displaying Copland models as graphs.
   Requires Graphviz.

 * scripts -- shell scripts.

   * copland2xhtml -- displays the abstract syntax and the event
     semantics of a Copland phrase.

   * coplandinit -- creates a makefile for copland2xhtml.

   * coplandchase -- analyzes a Copland phrase using a theory based on
     the confining paper (defunct).

   * coplandvalchase -- analyzes a Copland phrase using a theory based
     on the confining paper and using evidence values instead of types.

   * coplandchaseinit -- creates a makefile for copland2xhtml,
     coplandflow, and coplandchase.

   * coplandflow -- displays the abstract syntax, data flow and tamper
     properties of a Copland phrase.

   * distinct -- writes Chase assertions that make constants distinct.

   * htmlpre -- extracts the content of pre elements in an HTML document.

   * htmlquote -- quote special HTML characters for inclusion in pre
     elements.

 * sexpr -- a library for reading Chase S-expressions.

 * sexprsplit -- a program for displaying Chase models as XHTML.

 * tamper -- a library for computing tamper strategies from Copland
   data flow graphs.
