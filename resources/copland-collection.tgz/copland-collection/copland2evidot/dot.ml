(* graph Copland *)

open Format
open Copland
open Events

let cluster = true

type dot =
  | Event of plc * int * string   (* place, id, label *)
  | Data of plc * int * ev        (* place, id, evidence *)
  (* plc, source id, destination id, maybe color *)
  | Arrow of plc * int * int * string option * string option

let event p i lbl =
  Event (p, i, lbl)

let data p i ev =
  Data (p, i, ev)

let arrow ?color ?weight p i j =
  Arrow (p, i, j, color, weight)

let plc = function
  | Event (p, _, _) -> p
  | Data (p, _, _) -> p
  | Arrow (p, _, _, _, _) -> p

let seq = function
  | Seq _ -> true
  | Par _ -> false

let lft o ev =
  match o with
  | Seq Dup -> ev
  | Seq Lft -> ev
  | Par Dup -> ev
  | Par Lft -> ev
  | _ -> Mt

let rht o ev =
  match o with
  | Seq Dup -> ev
  | Seq Rht -> ev
  | Par Dup -> ev
  | Par Rht -> ev
  | _ -> Mt

let order = function
  | Seq Dup -> "+<+"
  | Seq Lft -> "+<-"
  | Seq Rht -> "-<+"
  | Seq Nil -> "-<-"
  | Par Dup -> "+~+"
  | Par Lft -> "+~-"
  | Par Rht -> "-~+"
  | Par Nil -> "-~-"

(* Compile a Copland phrase into a dot list *)
(* Variable i is the identifier of the source data *)
let rec comp t p pos ev_in i acc =
  let ev_out = eval t p pos ev_in in
  match t with
  | NUL ->
     let lbl = Printf.sprintf "%s: nul" p in
     i + 2,
     arrow p (i + 1) (i + 2)
     :: data p (i + 2) ev_out
     :: arrow p i (i + 1)
     :: event p (i + 1) lbl
     :: acc
  | CPY ->
     let lbl = Printf.sprintf "%s: cpy" p in
     i + 2,
     arrow p (i + 1) (i + 2)
     :: data p (i + 2) ev_out
     :: arrow p i (i + 1)
     :: event p (i + 1) lbl
     :: acc
  | MEAS (asp, q, target) ->
     let lbl = Printf.sprintf "%s: msp(%s, %s, %s, <%s>)"
                 p asp q target (show_pos pos) in
     i + 2,
     arrow p (i + 1) (i + 2)
     :: data p (i + 2) ev_out
     :: arrow p i (i + 1)
     :: event p (i + 1) lbl
     :: acc
  | SIG ->
     let lbl = Printf.sprintf "%s: sig" p in
     i + 2,
     arrow p (i + 1) (i + 2)
     :: data p (i + 2) ev_out
     :: arrow p i (i + 1)
     :: event p (i + 1) lbl
     :: acc
  | HSH ->
     let lbl = Printf.sprintf "%s: hsh" p in
     i + 2,
     arrow p (i + 1) (i + 2)
     :: data p (i + 2) ev_out
     :: arrow p i (i + 1)
     :: event p (i + 1) lbl
     :: acc
  | AT (q, t') ->
     let lbl = Printf.sprintf "%s: req(%s)" p q in
     let acc =
       arrow ~weight:"2.0" "" (i + 1) (i + 2)
       :: data q (i + 2) ev_in
       :: arrow p i (i + 1)
       :: event p (i + 1) lbl
       :: acc in
     let j, acc = comp t' q (0 :: pos) ev_in (i + 2) acc in
     let lbl = Printf.sprintf "%s: rpy(%s)" p q in
     j + 2,
     arrow p (j + 1) (j + 2)
     :: data p (j + 2) ev_out
     :: arrow ~color:"blue" p (i + 1) (j + 1)
     :: arrow "" j (j + 1)
     :: event p (j + 1) lbl
     :: acc
  | LN (t1, t2) ->
     let j, acc = comp t1 p (0 :: pos) ev_in i acc in
     comp t2 p (1 :: pos) (eval t1 p (0 :: pos) ev_in) j acc
  | BR (o, t1, t2) ->
     let lbl = Printf.sprintf "%s: %s split" p (order o) in
     let acc =
       arrow p (i + 1) (i + 2)
       :: data p (i + 2) (lft o ev_in)
       :: arrow p i (i + 1)
       :: event p (i + 1) lbl
       :: acc in
     let j, acc = comp t1 p (0 :: pos) (lft o ev_in) (i + 2) acc in
     let acc =
       arrow p (i + 1) (j + 1)
       :: data p (j + 1) (rht o ev_in)
       :: acc in
     let k, acc = comp t2 p (1 :: pos) (rht o ev_in) (j + 1) acc in
     let lbl = Printf.sprintf "%s: join" p in
     let acc =
       if seq o then
         arrow ~color:"red" p (j - 1) (j + 2) :: acc
       else acc in
     k + 2,
     arrow p (k + 1) (k + 2)
     :: data p (k + 2) ev_out
     :: arrow p k (k + 1)
     :: arrow p j (k + 1)
     :: event p (k + 1) lbl
     :: acc

let dot = function
  | (p, None, t) ->
     List.rev @@ snd @@ comp t p [] Mt 0 [data p 0 Mt]
  | (p, Some n, t) ->
     let no = No n in
     List.rev @@ snd @@ comp t p [] no 0 [data p 0 no]

let pp_dot f = function
  | Event (_, i, lbl) ->
     fprintf f "  n%d [shape=ellipse, label=\"%s\"]@." i lbl
  | Data (_, i, ev) ->
     fprintf f "  n%d [shape=box, label=\"" i;
     pp_print_flush f ();
     print_ev f ev;
     fprintf f "\"]@."
  | Arrow (_, i, j, color, weight) ->
     fprintf f "  n%d -> n%d" i j;
     match color, weight with
     | None, None -> fprintf f "@."
     | Some color, None ->
        fprintf f " [color=%s]@." color
     | None, Some weight ->
        fprintf f " [weight=%s]@." weight
     | Some color, Some weight ->
        fprintf f " [color=%s, weight=%s]@." color weight

module StringKey =
  struct
    type t = string
    let compare = compare
  end

module StringMap = Map.Make(StringKey)

let load_dot m dot =
  let key = plc dot in
  match StringMap.find_opt key m with
  | None -> StringMap.add key [dot] m
  | Some dots -> StringMap.add key (dot :: dots) m

let show_cluster f (p, dots) =
  if String.length p > 0 then
    begin
      fprintf f " subgraph cluster_%s {@." p;
      fprintf f "  label=\"%s\"@." p
    end;
  List.iter (pp_dot f) dots;
  if String.length p > 0 then
    fprintf f " }@."

let print_cluster f d =
  fprintf f "  labeljust=right@.";
  let m = List.fold_left load_dot StringMap.empty d in
  List.iter (show_cluster f) (StringMap.bindings m)

let print_dot f d =
  fprintf f "digraph Copland {@.";
  if cluster then
    print_cluster f d
  else
    List.iter (pp_dot f) d;
  fprintf f "}@."
