(* The copland2evidot program *)
