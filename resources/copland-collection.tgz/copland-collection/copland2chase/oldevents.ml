(* Generate Copland event semantics *)

open Copland

type node = int

type src =
  | Void
  | Node of int

(* Copland event labels *)

type label =
  | Nul of plc
  | Cpy of plc * src
  | Msp of plc * src * string * plc * string
  | Sig of plc * src
  | Hsh of plc * src
  | Req of plc * src * plc
  | Rpy of plc * node * plc
  | Split of plc * src * dir
  | Join of plc * node * node * string

type stmt =
  | Lbl of node * label
  | Prec of node * node

type stmts = stmt list

(* Location used to store output *)

let buf = ref ([] : stmt list)

(* Generate fresh integers used as events *)
let fresh =
  let gen = ref 0 in
  fun () ->
  let i = !gen in
  incr gen;
  i

(* Create an event and declare its label. *)
let event lbl =
  let n = fresh () in
  buf := Lbl (n, lbl) :: !buf;
  n

(* Assert a precedence relation between two nodes when the source is
   not void. *)
let succ src dst =
  match src with
  | Void -> ()
  | Node n ->
     buf := Prec (n, dst) :: !buf

let ord = function
  | Seq d -> "seq", d
  | Par d -> "par", d

let seq = function
  | Seq _ -> true
  | Par _ -> false

let lft o =
  match o with
  | Seq Dup -> true
  | Seq Lft -> true
  | Par Dup -> true
  | Par Lft -> true
  | _ -> false

let rht o =
  match o with
  | Seq Dup -> true
  | Seq Rht -> true
  | Par Dup -> true
  | Par Rht -> true
  | _ -> false

(* Event labels for each type of event *)
let nul p =
  event (Nul p)

let cpy p src =
  event (Cpy (p, src))

let meas p src probe q target =
  event (Msp (p, src, probe, q, target))

let sigg p src =
  event (Sig (p, src))

let hsh p src =
  event (Hsh (p, src))

let req p src q =
  event (Req (p, src, q))

let rpy p src q =
  event (Rpy  (p, src, q))

let split p src d =
  event (Split (p, src, d))

let join p lft rht b =
  event (Join (p, lft, rht, b))

(* Compile a Copland phrase into an item list.

   src is source of evidence (could be void when there is none).

   pred is the previous node (initially void, otherwise a node).
 *)
let rec comp t p src prec =
  match t with
  | NUL ->
     let n = nul p in           (* Create event *)
     succ prec n;               (* Add prec relation *)
     n
  | CPY ->
     let n = cpy p src in
     succ prec n;
     n
  | MEAS (probe, q, target) ->
     let n = meas p src probe q target in
     succ prec n;
     n
  | SIG ->
     let n = sigg p src in
     succ prec n;
     n
  | HSH ->
     let n = hsh p src in
     succ prec n;
     n
  | AT (q, t') ->
     let n = req p src q in
     succ prec n;
     let m = comp t' q (Node n) (Node n) in
     let n = rpy p m q in
     succ (Node m) n;
     n
  | LN (t1, t2) ->
     let n = comp t1 p src prec in
     comp t2 p (Node n) (Node n)
  | BR (o, t1, t2) ->
     let b, d = ord o in
     let n = split p src d in
     succ prec n;
     let l = comp t1 p (if lft o then (Node n) else Void) (Node n) in
     let pred = if seq o then l else n in
     let r = comp t2 p (if rht o then (Node n) else Void) (Node pred) in
     let n = join p l r b in
     if not (seq o) then succ (Node l) n;
     succ (Node r) n;
     n

(* A simple transitive closure.  As soon as there is progress, restart
   the whole loop. *)

let rec tc_start stmts =
  tc_outer stmts stmts

(* Find a pair of nodes *)
and tc_outer stmts = function
  | [] -> stmts
  | Lbl _ :: oss -> tc_outer stmts oss
  | Prec (n1, n2) :: oss -> tc_inner stmts oss n1 n2 stmts

(* Try to add prec relation *)
and tc_inner stmts oss n1 n2 = function
  | [] -> tc_outer stmts oss    (* Nothing to do *)
  | Lbl _ :: iss -> tc_inner stmts oss n1 n2 iss
  | Prec (n3, n4) :: iss ->
     if n2 = n3 && not (List.mem (Prec (n1, n4)) stmts) then
       tc_start (Prec (n1, n4) :: stmts)
     else
       tc_inner stmts oss n1 n2 iss

(* Compute the transitive closure of the precedence relation.  Put the
   added stmts at the end of the list by performing the two reverse
   operations. *)

let tc stmts =
  List.rev @@ tc_start @@ List.rev stmts

(* Extract the nodes associated with measurement events *)
let meas_nodes stmts =
  let f ns = function
    | Lbl (n, Msp (_, _, _, _, _)) -> n :: ns
    | _ -> ns in
  List.fold_left f [] stmts

(* Extract a measurement event semantics from some Copland events *)

let meas_events stmts =
  let ns = meas_nodes stmts in
  let f = function
    | Lbl (_, Msp (_, _, _, _, _)) -> true
    | Lbl _ -> false
    | Prec (n1, n2) ->
       List.mem n1 ns && List.mem n2 ns in
  List.filter f @@ tc stmts

(* Generate the events and their orderings from a Copland phrase. *)

let events (p, _, t) =
  let _ = comp t p Void Void in
  List.rev !buf
