(* The coplandval2measchase program *)
