(* Generate Copland event semantics as Geolog *)

open Copland
open Events
open Geolog

(* Show an event node *)
let node i =
  cn ("v" ^ string_of_int i)

let src = function
  | Void -> cn "void"
  | Node i -> node i

let plc = cn

(* For branching *)
let dir  = function
  | Dup -> cn "dup"
  | Lft -> cn "lft"
  | Rht -> cn "rht"
  | Nil -> cn "nil"

(* Event labels for each type of event *)
let lbl = function
  | Nul p -> fn "nul" [plc p]
  | Cpy (p) -> fn "cpy" [plc p]
  | Msp (p, probe, q, target, pos) ->
     fn "msp" [plc p; cn probe; plc q; cn target; cn ("x" ^ show_pos pos)]
  | Sig (p) -> fn "sig" [plc p]
  | Hsh (p) -> fn "hsh" [plc p]
  | Req (p, q) -> fn "req" [plc p; plc q]
  | Rpy (p, q) -> fn "rpy" [plc p; plc q]
  | Split (p, d) -> fn "split" [plc p; dir d]
  | Join (p, b) -> fn "join" [plc p; cn b]

let geolog_event = function
  | Lbl (n, l, _) -> eq (fn "l" [node n]) (lbl l)
  | Prec (n, m) -> pred "prec" [node n; node m]
  | Feeds (n, m) -> pred "feeds" [src n; node m]
  | Fuels (n, m) -> pred "fuels" [node n; node m]

let chase evts =
  [], [List.map geolog_event evts]

(* prec(X, Y) & prec(Y, Z) => prec(X, Z). *)
let prec_trans () =
  [pred "prec" [vr "X"; vr "Y"]; pred "prec" [vr "Y"; vr "Z"]],
  [[pred "prec" [vr "X"; vr "Z"]]]

(* Extract the nodes associated with measurement events *)
let meas_nodes stmts =
  let f ns = function
    | Lbl (n, Msp (_, _, _, _, _), _) -> n :: ns
    | _ -> ns in
  List.sort compare @@ List.fold_left f [] stmts

let node_assumptions stmts =
  let ns = meas_nodes stmts in
  let atom n = [eq (vr "E") (node n)] in
  [pred "ms_evt" [vr "E"]], List.map atom ns

(* Ensure constants that model system components remain distinct. *)

let add x xs =
  if List.mem x xs then
    xs
  else
    x :: xs

(* Collect the components referred in a measurements. *)

let components stmts =
  let f xs = function
    | Lbl (_, Msp (_, probe, _, target, _), _) ->
       add probe (add target xs)
    | _ -> xs in
  List.sort compare @@ List.fold_left f [] stmts

(* Construct the formulas that assert that constants for components
   remain distinct. *)
let distinct stmts =
  let diff x y = [eq (cn x) (cn y)], [] in
  let rec inner acc x = function
    | [] -> acc
    | y :: xs ->
       inner (diff x y :: acc) x xs in
  let rec outer acc = function
    | [] -> acc
    | x :: xs ->
       outer (inner acc x xs) xs in
  List.rev @@ outer [] @@ components stmts

(* Returns the assumptions associated with a Copland phrase.  The
   formula [], [] causes a newline to be printed. *)

(* Enable a temporary hack *)
let hack = true

let assumptions stmts =
  if hack then
    [node_assumptions stmts]
  else
    node_assumptions stmts :: ([], []) :: distinct stmts
