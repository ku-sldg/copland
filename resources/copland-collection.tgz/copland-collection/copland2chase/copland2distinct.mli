(* The copland2distinct program *)
