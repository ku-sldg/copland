val chase : Events.stmts -> Geolog.geolog
val prec_trans : unit -> Geolog.geolog
val assumptions : Events.stmts -> Geolog.geolog list
