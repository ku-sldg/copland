val chase : Oldevents.stmts -> Geolog.geolog
val prec_trans : unit -> Geolog.geolog
val assumptions : Oldevents.stmts -> Geolog.geolog list
