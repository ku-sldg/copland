(* Translate a Copland phrase into distinct axioms *)

open Filter
open Copland
open Events
open Geolog

module OrderedString =
  struct
    type t = string
    let compare = compare
  end

module SSet = Set.Make(OrderedString)

let extract set = function
  | Lbl (_, Msp (src, probe, dest, target, _), _) ->
     SSet.add target @@ SSet.add dest @@
       SSet.add probe @@ SSet.add src set
  | _ -> set

let symbols evs =
  SSet.elements @@ List.fold_left extract SSet.empty evs

let axiom left right =
  [eq (cn left) (cn right)], []

let rec axioms = function
  | [] -> []
  | x :: xs ->
     List.map (axiom x) xs @ axioms xs

let distinct events =
  axioms @@ symbols events

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let g = distinct @@ events t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  List.iter (Geolog.print_form f) g;
  close_out o

let () =
  filter "0.1" go
