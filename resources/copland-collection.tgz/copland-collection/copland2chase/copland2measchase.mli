(* The copland2measchase program *)
