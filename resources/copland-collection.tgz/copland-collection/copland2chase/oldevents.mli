open Copland
type node = int
type src = Void | Node of int
type label =
    Nul of plc
  | Cpy of plc * src
  | Msp of plc * src * string * plc * string
  | Sig of plc * src
  | Hsh of plc * src
  | Req of plc * src * plc
  | Rpy of plc * node * plc
  | Split of plc * src * dir
  | Join of plc * node * node * string
type stmt = Lbl of node * label | Prec of node * node
type stmts = stmt list
val tc : stmts -> stmts
val meas_events : stmts -> stmts
val events : copland -> stmts
