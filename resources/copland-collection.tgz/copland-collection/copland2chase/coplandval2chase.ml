(* Translate a Copland phrase into a Chase axiom *)

open Filter
open Copland
open Events
open Chase

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let g = chase @@ events t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  Geolog.print_form f g;
  Format.pp_print_newline f ();
  Geolog.print_form f (prec_trans ());
  close_out o

let () =
  filter "0.1" go
