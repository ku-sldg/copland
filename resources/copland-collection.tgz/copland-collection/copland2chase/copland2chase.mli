(* The copland2chase program *)
