(* Translate a Copland phrase into an event semantics diagram in
   Graphvis dot notation *)

open Filter
open Copland
open Dot

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let d = dot t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  print_dot f d;
  close_out o

let () =
  filter "0.1" go
