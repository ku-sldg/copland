type dot
val dot : Copland.copland -> dot list
val print_dot : Format.formatter -> dot list -> unit
