(* graph Copland *)

open Format
open Copland
open Events

let cluster = true

type dot =
  | Event of plc * int * string   (* place, id, label *)
  (* source id, destination id, maybe color, maybe weight *)
  | Arrow of int * int * string option * string option

(* Location used to store dot output *)
let buf = ref ([] : dot list)

(* Generate fresh integers used to label events *)
let fresh =
  let gen = ref 0 in
  fun () ->
  let i = !gen in
  incr gen;
  i

let event p lbl =
  let i = fresh () in
  buf := Event (p, i, lbl) :: !buf;
  i

let arrow ?color ?weight src dst =
  match src with
  | None -> ()
  | Some src ->
     buf := Arrow (src, dst, color, weight) :: !buf

let item p lbl src =
  let i = event p lbl in
  arrow src i;
  i

let plc = function
  | Event (p, _, _) -> p
  | Arrow (_, _, _, _) -> ""

let seq = function
  | Seq _ -> true
  | Par _ -> false

let order = function
  | Seq Dup -> "+<+"
  | Seq Lft -> "+<-"
  | Seq Rht -> "-<+"
  | Seq Nil -> "-<-"
  | Par Dup -> "+~+"
  | Par Lft -> "+~-"
  | Par Rht -> "-~+"
  | Par Nil -> "-~-"

(* Compile a Copland phrase into a dot list *)
(* Variable i is the identifier of the source data *)
let rec comp t p pos src =
  match t with
  | NUL ->
     let lbl = Printf.sprintf "%s: nul" p in
     item p lbl src
  | CPY ->
     let lbl = Printf.sprintf "%s: cpy" p in
     item p lbl src
  | MEAS (asp, q, target) ->
     let lbl = Printf.sprintf "%s: msp(%s, %s, %s, <%s>)"
                 p asp q target (show_pos pos) in
     item p lbl src
  | SIG ->
     let lbl = Printf.sprintf "%s: sig" p in
     item p lbl src
  | HSH ->
     let lbl = Printf.sprintf "%s: hsh" p in
     item p lbl src
  | AT (q, t') ->
     let lbl = Printf.sprintf "%s: req(%s)" p q in
     let i = item p lbl src in
     let j = comp t' q (0 :: pos) (Some i) in
     let lbl = Printf.sprintf "%s: rpy(%s)" p q in
     item p lbl (Some j)
  | LN (t1, t2) ->
     let i = comp t1 p (0 :: pos) src in
     comp t2 p (1 :: pos) (Some i)
  | BR (o, t1, t2) ->
     let lbl = Printf.sprintf "%s: %s split" p (order o) in
     let i = item p lbl src in
     let j = comp t1 p (0 :: pos) (Some i) in
     let k = comp t2 p (1 :: pos) (Some (if seq o then j else i)) in
     let lbl = Printf.sprintf "%s: join" p in
     let i = item p lbl (Some k) in
     if not (seq o) then
       arrow (Some j) i;
     i

let dot (p, _, t) =
  let _ = comp t p [] None in
  List.rev !buf

let pp_dot f = function
  | Event (_, i, lbl) ->
     fprintf f "  n%d [shape=ellipse, label=\"%s\"]@." i lbl
  | Arrow (i, j, color, weight) ->
     fprintf f "  n%d -> n%d" i j;
     match color, weight with
     | None, None -> fprintf f "@."
     | Some color, None ->
        fprintf f " [color=%s]@." color
     | None, Some weight ->
        fprintf f " [weight=%s]@." weight
     | Some color, Some weight ->
        fprintf f " [color=%s, weight=%s]@." color weight

module StringKey =
  struct
    type t = string
    let compare = compare
  end

module StringMap = Map.Make(StringKey)

let load_dot m dot =
  let key = plc dot in
  match StringMap.find_opt key m with
  | None -> StringMap.add key [dot] m
  | Some dots -> StringMap.add key (dot :: dots) m

let show_cluster f (p, dots) =
  if String.length p > 0 then
    begin
      fprintf f " subgraph cluster_%s {@." p;
      fprintf f "  label=\"%s\"@." p
    end;
  List.iter (pp_dot f) dots;
  if String.length p > 0 then
    fprintf f " }@."

let print_cluster f d =
  fprintf f "  labeljust=right@.";
  let m = List.fold_left load_dot StringMap.empty d in
  List.iter (show_cluster f) (StringMap.bindings m)

let print_dot f d =
  fprintf f "digraph Copland {@.";
  if cluster then
    print_cluster f d
  else
    List.iter (pp_dot f) d;
  fprintf f "}@."
