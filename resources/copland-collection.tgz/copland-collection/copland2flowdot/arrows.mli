val arrows : string -> (string -> in_channel -> string -> bool -> bool -> unit) -> unit
