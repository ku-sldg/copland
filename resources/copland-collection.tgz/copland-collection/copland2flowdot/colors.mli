val color : unit -> string
