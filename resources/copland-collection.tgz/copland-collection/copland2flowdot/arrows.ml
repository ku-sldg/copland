(* Command-line processing for copland2flowdot using Getopt *)

let usage =
  Printf.sprintf
    "Usage: %s [OPTIONS] [INPUT]\n\
    Options:\n\
    \  -o FILE  --output=FILE  output to file (default is standard output)\n\
    \  -v       --version      print version number\n\
    \  -h       --help         print this message\n\
    \  -f       --no-flow      suppress data flow arrows\n\
    \  -t       --tmpr         show tamper strategy arrows"
    Sys.argv.(0)

let output  = ref ""
let version = ref false
let help    = ref false
let flow    = ref true
let tmpr    = ref false

let specs =
[
 ('o', "output",  None, Getopt.atmost_once output
                          (Getopt.Error "only one output"));
 ('v', "version", Getopt.set version true, None);
 ('h', "help", Getopt.set help true, None);
 ('f', "no-flow", Getopt.set flow false, None);
 ('t', "tmpr", Getopt.set tmpr true, None)
]

let cmdline v specs =
  let args = ref [] in
  let add_arg arg = args := arg :: !args in
  (try
     Getopt.parse_cmdline specs add_arg
   with
   | Getopt.Error s ->
      prerr_endline s;
      prerr_endline "";
      prerr_endline usage;
      exit 1);
  if !help then
    begin
      print_endline usage;
      exit 0
    end
  else if !version then
    begin
      print_endline v;
      exit 0
    end
  else
    List.rev !args

let start version go =
  let (in_name, in_ch) =
    match cmdline version specs with
    | [] -> ("", stdin)
    | [f] -> (try (f, open_in f)
              with Sys_error s -> failwith s)
    | _ ->
	prerr_endline "Bad command-line argument count\n";
	prerr_endline usage;
	exit 1 in
  go in_name in_ch !output !flow !tmpr

let arrows version go =
  try
    start version go
  with
  | Failure s ->
      prerr_endline s;
      exit 1
