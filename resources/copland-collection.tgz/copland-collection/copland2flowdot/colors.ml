(* Generate different arrow colors for tamper strategies *)

(* A subset of SVG color options *)
let colors = [|
    "red";
    "blue";
    "green";
    "indigo";
    "sienna";
    "hotpink";
    "maroon";
    "goldenrod";
    "aqua";
    "tomato";
    "aquamarine";
    "chartreuse";
    "cornflowerblue";
    "darkcyan";
    "darkolivegreen";
    "fuchsia";
    "salmon";
    "teal";
    "seagreen";
    "orangered";
    "mediumslateblue";
    "navy";
    "mediumvioletred";
    "yellow";
    "tan";
    "springgreen";
    "olive"
  |]

let len_colors = Array.length colors

(* Generate fresh integers used as indices into colors *)
let fresh =
  let gen = ref 0 in
  fun () ->
  let i = !gen in
  incr gen;
  i

(* Get the next arrow color *)
let color () =
  let indx = fresh () mod len_colors in
  colors.(indx)
