(* Translate a Copland phrase into dot showing its data flow and
   tamper properties *)

open Arrows
open Colors
open Copland
open Events
open Flow
open Printf
open Tamper

(* Print an event's label *)
let show_lbl o = function
  | Nul p -> fprintf o "%s: nul" p
  | Cpy p -> fprintf o "%s: cpy" p
  | Msp (p, prb, q, tgt, _) ->
     fprintf o "%s: msp(%s, %s, %s)" p prb q tgt
  | Sig p -> fprintf o "%s: sig" p
  | Hsh p -> fprintf o "%s: hsh" p
  | Req (p, q) -> fprintf o "%s: req(%s)" p q
  | Rpy (p, q) -> fprintf o "%s: rpy(%s)" p q
  | Split (p, _) -> fprintf o "%s: split" p
  | Join (p, _) -> fprintf o "%s: join" p

(* Print dot for a data flow graph *)
let show_flow_dot o flow graph =
  let g o v v1 =
    fprintf o "  n%d -> n%d\n" v1 v in
  let f o node =
    let v = node.node in
    fprintf o "  n%d [label=\"" v;
    show_lbl o node.lbl;
    fprintf o "\"]\n";
    if flow then List.iter (g o v) node.src in
  Array.iter (f o) graph

(* Print dot for tamper properties *)
let show_tmpr_dot o graph =
  let h o v c v1 =
    fprintf o "  n%d -> n%d [color=%s]\n" v1 v c in
  let g o v stgy =
    let c = color () in
    List.iter (h o v c) stgy in
  let f o v = function
    | [[]] -> ()
    | ss -> List.iter (g o v) ss in
  Array.iteri (f o) (meas_stgys graph)

(* Orchestrates dot printing *)
let show_dot o graph flow tmpr =
  fprintf o "digraph DataFlow {\n";
  show_flow_dot o flow graph;
  if tmpr then show_tmpr_dot o graph;
  fprintf o "}\n"

(* Main routine *)
let go ifile i ofile flow tmpr =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  let graph = data_flow t in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  show_dot o graph flow tmpr;
  close_out o

let () =
  arrows "0.1" go
