open Copland
type thread = Thrd of plc * stmt list
and stmt =
  | Null
  | Copy
  | Meas of meas
  | Sign
  | Hash
  | Call of thread
  | Push
  | Swap
  | Merge
  | Fork of stmt list
  | Join
val threads : copland -> thread
val print_threads : Format.formatter -> thread -> unit
