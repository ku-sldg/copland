(* Copland threads *)

open Format
open Copland

type thread = Thrd of plc * stmt list
and stmt =
  | Null
  | Copy
  | Meas of meas
  | Sign
  | Hash
  | Call of thread
  | Push
  | Swap
  | Merge
  | Fork of stmt list
  | Join

let split dir =
  match dir with
  | Dup -> ([], [])
  | Lft -> ([], [Null])
  | Rht -> ([Null], [])
  | Nil -> ([Null], [Null])

(* Compile a Copland phrase. *)

let rec comp p = function
  | NUL -> [Null]
  | CPY -> [Copy]
  | MEAS m -> [Meas m]
  | SIG -> [Sign]
  | HSH -> [Hash]
  | AT (q, t) -> [Call (Thrd (q, comp q t))]
  | LN (t1, t2) -> comp p t1 @ comp p t2
  | BR (Seq d, t1, t2) ->
     let (lft, rht) = split d in
     [Push] @ lft @ comp p t1 @ [Swap] @ rht @ comp p t2 @ [Merge]
  | BR (Par d, t1, t2) ->
     let (lft, rht) = split d in
     [Fork (rht @ comp p t2)] @ lft @ comp p t1 @ [Join]

let threads (p, _, t) = Thrd (p, comp p t)

let sep f () =
  fprintf f ";@ "

let rec print_thread f (Thrd (p, thr)) =
  fprintf f "%s:" p;
  print_stmts f thr;

and print_stmts f thr =
  fprintf f "[@[<2>";
  pp_print_list ~pp_sep:sep print_stmt f thr;
  fprintf f "]@]"

and print_stmt f = function
  | Null -> pp_print_string f "null"
  | Copy -> pp_print_string f "copy"
  | Meas (probe, q, target) ->
     fprintf f "meas %s %s %s" probe q target
  | Sign -> pp_print_string f "sign"
  | Hash -> pp_print_string f "hash"
  | Call thr ->
     fprintf f "call ";
     print_thread f thr
  | Push -> pp_print_string f "push"
  | Swap -> pp_print_string f "swap"
  | Merge -> pp_print_string f "merge"
  | Fork stmts ->
     fprintf f "fork ";
     print_stmts f stmts
  | Join -> pp_print_string f "join"

let print_threads f thr =
  print_thread f thr;
  pp_print_newline f ()
