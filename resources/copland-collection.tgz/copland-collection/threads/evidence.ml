(* Copland evidence types *)

open Format
open Copland

(* Evidence returned from an execution *)
type ev =
  | Mt                          (* Empty evidence *)
  | No of string                (* Starting nonce *)
  | Ms of meas * plc * ev       (* Measurement *)
  | G of ev * plc               (* Signature *)
  | H of ev * plc               (* Hash *)
  | S of ev * ev                (* Sequential composition *)
  | P of ev * ev                (* Parallel composition *)

let split dir e =               (* How to split evidence *)
  match dir with
  | Dup -> (e, e)
  | Lft -> (e, Mt)
  | Rht -> (Mt, e)
  | Nil -> (Mt, Mt)

(* Compute the evidence associate with phrase (Fig 3. Evidence
   Semantics *)
let rec eval t p e =
  match t with
  | NUL -> Mt
  | CPY -> e
  | MEAS ms -> Ms (ms, p, e)
  | SIG -> G (e, p)
  | HSH -> H (e, p)
  | AT (q, t) -> eval t q e
  | LN (t1, t2) -> eval t2 p (eval t1 p e)
  | BR (Seq dir, t1, t2) ->
     let e1, e2 = split dir e in
     S (eval t1 p e1, eval t2 p e2)
  | BR (Par dir, t1, t2) ->
     let e1, e2 = split dir e in
     P (eval t1 p e1, eval t2 p e2)

(* Top level evidence *)
let ev = function
  | (p, None, t) -> eval t p Mt
  | (p, Some n, t) -> eval t p (No n)

let rec print_ev f = function
  | Mt ->
     fprintf f "mt";
  | No n ->
     fprintf f "#%s" n;
  | Ms (m, p, e) ->
     fprintf f "m(";
     print_meas f m;
     fprintf f ", %s, " p;
     print_ev f e;
     fprintf f ")"
  | G (e, p) ->
     fprintf f "g(";
     print_ev f e;
     fprintf f ", %s)" p
  | H (e, p) ->
     fprintf f "h(";
     print_ev f e;
     fprintf f ", %s)" p
  | S (e1, e2) ->
     fprintf f "@[<2>s(";
     print_ev f e1;
     fprintf f ",@ ";
     print_ev f e2;
     fprintf f ")@]"
  | P (e1, e2) ->
     fprintf f "@[<2>p(";
     print_ev f e1;
     fprintf f ",@ ";
     print_ev f e2;
     fprintf f ")@]"
