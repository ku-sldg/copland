(* The coplandrunthreads program *)
