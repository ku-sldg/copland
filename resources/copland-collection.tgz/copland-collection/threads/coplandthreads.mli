(* The coplandthreads program *)
