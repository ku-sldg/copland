(* Pretty print a Copland thread *)

open Margin
open Copland
open Threads

(* Main routine *)
let go margin ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  if margin > 0 then
    Format.pp_set_margin f margin; (* Set margin *)
  let thrds = threads t in
  print_threads f thrds;
  close_out o

let () =
  filter "0.1" go
