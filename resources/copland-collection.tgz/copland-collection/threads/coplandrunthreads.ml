(* Run a Copland thread and print the results *)

open Margin
open Copland
open Evidence
open Threads

(* Stack operations *)

(* Retrieve the value a the top of the stack. *)

let top = function
  | [] -> failwith "top"
  | x :: _ -> x

(* Assign a value to the top of the stack. *)

let assign x = function
  | [] -> failwith "assign"
  | _ :: xs -> x :: xs

(* Pop the stack. *)

let pop = function
  | [] -> failwith "pop"
  | _ :: xs -> xs

(* Duplicate the top value on the stack. *)

let dup = function
  | [] -> failwith "dup"
  | x :: xs -> x :: x :: xs

(* Push a value on the stack *)

let push x xs = x :: xs

(* Swap the top two values on the stack. *)

let swap = function
  | x :: y :: xs -> y :: x :: xs
  | _ -> failwith "swap"

(* A state is a stack of evidence and a stack of forked threads.
   Since we have no parallelism in the Ocaml runtime, we instead
   evaluate a forked thread immediately, and store the results in a
   stack of thread results. *)

type state = {
    mutable stack: ev list;
    mutable threads: ev list;
  }

(* Create a new fresh state with the evidence pushed on the stack. *)

let new_state ev =
  { stack = [ev];
    threads = [];
  }

(* Make a copy of a state. *)

let copy_state state =
  { stack = state.stack;
    threads = state.threads;
  }

(* This is the virtual machine that runs threads. *)

let rec run_threads (Thrd (plc, stmts)) ev =
  run_stmts plc (new_state ev) stmts

(* Execute the statements in a thread. *)

and run_stmts plc state = function
  | [] -> top state.stack
  | stmt :: stmts ->
     let state = run_stmt plc state stmt in
     run_stmts plc state stmts

(* Execute a statement by updating the state. *)

and run_stmt plc state = function

  (* Overwrite the top of the stack with Mt. *)
  | Null ->
     state.stack <- assign Mt state.stack;
     state

  (* Copy is a no-op. *)
  | Copy -> state

  (* Overwrite the top of the stack with measurement output. *)
  | Meas meas ->
     let ev = Ms (meas, plc, top state.stack) in
     state.stack <- assign ev state.stack;
     state

  (* Overwrite the top of the stack with a signature. *)
  | Sign ->
     let ev = G (top state.stack, plc) in
     state.stack <- assign ev state.stack;
     state

  (* Overwrite the top of the stack with a hash. *)
  | Hash ->
     let ev = H (top state.stack, plc) in
     state.stack <- assign ev state.stack;
     state

  (* Run a thread remotely.  Overwrite the top of the stack with the
     result. *)
  | Call thrd ->
     let ev = run_threads thrd (top state.stack) in
     state.stack <- assign ev state.stack;
     state

  (* The next three statements are use to compile sequential branch
     phrases. *)

  (* Duplicate the value on the top of the stack. *)
  | Push ->
     state.stack <- dup state.stack;
     state

  (* Swap the top two values on the stack. *)
  | Swap ->
     state.stack <- swap state.stack;
     state

  (* Report the results of a sequential branch by merging the top two
     values on the stack. *)
  | Merge ->
     let ev = top state.stack in
     state.stack <- pop state.stack;
     let ev = S (top state.stack, ev) in
     state.stack <- assign ev state.stack;
     state

  (* The next two statements are used to compile parallel branch
     phrases. *)

  (* Simulate a process fork by duplicating the state, and running the
     statements. *)
  | Fork stmts ->
     let ev = run_stmts plc (copy_state state) stmts in
     state.threads <- push ev state.threads;
     state

  (* Simulate a process join by grabbing the thread result from the
     thread result stack.  Report the results of a parallel branch by
     merging that value with top value on the stack. *)
  | Join ->
     let ev = top state.threads in
     state.threads <- pop state.threads;
     state.stack <- assign (P (top state.stack, ev)) state.stack;
     state

(* Main routine *)
let go margin ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  if margin > 0 then
    Format.pp_set_margin f margin; (* Set margin *)
  let thrds = threads t in
  let ev = run_threads thrds Mt in
  print_ev f ev;
  Format.pp_print_newline f ();
  close_out o

let () =
  filter "0.1" go
