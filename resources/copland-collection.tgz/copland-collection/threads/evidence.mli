open Copland
type ev =
  | Mt
  | No of string
  | Ms of meas * plc * ev
  | G of ev * plc
  | H of ev * plc
  | S of ev * ev
  | P of ev * ev
val split : dir -> ev -> ev * ev
val eval : phrase -> plc -> ev -> ev
val ev : copland -> ev
val print_ev : Format.formatter -> ev -> unit
