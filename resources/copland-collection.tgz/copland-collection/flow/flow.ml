(* Compute data flow graphs for Copland phrases *)

(* A flow graph is an array that maps a node to its flow_node.  Use
   Array.get to perform the mapping. *)

open Events

type flow_node = {
    node : node;       (* The event number in the flow graph *)
    lbl : label;       (* The event's label *)
    evi : ev;          (* The event's evidence *)
    src : node list;   (* The sources of evidence used by the event *)
  }

type flow_graph = flow_node array

(* Extract the sources of evidence for a given event node. *)
let rec stmts2src node = function
  | [] -> []
  | Feeds (Node (x), y) :: stmts when y == node ->
     x :: stmts2src node stmts
  | Fuels (x, y) :: stmts when y == node ->
     x :: stmts2src node stmts
  | _ :: stmts -> stmts2src node stmts

(* Extract the graph nodes. *)
let stmts2nodes stmts =
  let rec f = function
    | [] -> []
    | Lbl (node, lbl, evi) :: ss ->
       { node = node;
         lbl = lbl;
         evi = evi;
         src = stmts2src node stmts;
       } :: f ss
    | _ :: ss -> f ss
  in f stmts

(* Construct a flow_graph from statements. *)
let stmts2graph stmts =
  let nodes = stmts2nodes stmts in (* Build the nodes *)
  (* Sort nodes based the node field *)
  let cmp a b = compare (a.node) (b.node) in
  let sorted_nodes = List.sort cmp nodes in
  (* Note that the nodes are a prefix of the natural numbers, and
     therefore can be used to look up a graph_node in the array
     below. *)
  Array.of_list sorted_nodes

(* Compute the data flow graph for a Copland phrase. *)
let data_flow cop = stmts2graph (events cop)
