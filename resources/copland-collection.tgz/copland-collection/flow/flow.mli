open Copland
open Events

type flow_node = {
    node : node;
    lbl : label;
    evi : ev;
    src : node list;
  }

type flow_graph = flow_node array

val data_flow : copland -> flow_graph
