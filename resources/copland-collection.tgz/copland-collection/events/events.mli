open Copland
type pos = int list
val show_pos : pos -> string
type ev =
  | Mt
  | No of string
  | Ms of meas * plc * pos * ev
  | G of ev * plc
  | H of ev * plc
  | S of ev * ev
  | P of ev * ev
val split : dir -> ev -> ev * ev
val eval : phrase -> plc -> pos -> ev -> ev
val ev : copland -> ev
val print_ev : Format.formatter -> ev -> unit
type node = int
type src = Void | Node of int
type label =
    Nul of plc
  | Cpy of plc
  | Msp of plc * string * plc * string * pos
  | Sig of plc
  | Hsh of plc
  | Req of plc * plc
  | Rpy of plc * plc
  | Split of plc * dir
  | Join of plc * string
type stmt =
    Lbl of node * label * ev
  | Prec of node * node
  | Feeds of src * node
  | Fuels of node * node
type stmts = stmt list
val tc : stmts -> stmts
val meas_events : stmts -> stmts
val events : copland -> stmts
