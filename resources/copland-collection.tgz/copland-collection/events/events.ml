(* Generate Copland evidence and event semantics using measurement values *)

open Format
open Copland

type pos = int list

let show_pos pos =
  let f i acc = acc ^ string_of_int i in
  List.fold_right f pos ""

(* Evidence returned from an execution *)
type ev =
  | Mt                          (* Empty evidence *)
  | No of string                (* Starting nonce *)
  | Ms of meas * plc * pos * ev (* Measurement *)
  | G of ev * plc               (* Signature *)
  | H of ev * plc               (* Hash *)
  | S of ev * ev                (* Sequential composition *)
  | P of ev * ev                (* Parallel composition *)

let split dir e =               (* How to split evidence *)
  match dir with
  | Dup -> (e, e)
  | Lft -> (e, Mt)
  | Rht -> (Mt, e)
  | Nil -> (Mt, Mt)

(* Compute the evidence associate with phrase (Fig 3. Evidence
   Semantics *)
let rec eval t p pos e =
  match t with
  | NUL -> Mt
  | CPY -> e
  | MEAS ms -> Ms (ms, p, pos, e)
  | SIG -> G (e, p)
  | HSH -> H (e, p)
  | AT (q, t) -> eval t q (0 :: pos) e
  | LN (t1, t2) -> eval t2 p (1 :: pos) (eval t1 p (0 :: pos) e)
  | BR (Seq dir, t1, t2) ->
     let e1, e2 = split dir e in
     S (eval t1 p (0 :: pos) e1, eval t2 p (1 :: pos) e2)
  | BR (Par dir, t1, t2) ->
     let e1, e2 = split dir e in
     P (eval t1 p (0 :: pos) e1, eval t2 p (1 :: pos) e2)

(* Top level evidence *)
let ev = function
  | (p, None, t) -> eval t p [] Mt
  | (p, Some n, t) -> eval t p [] (No n)

let rec print_ev f = function
  | Mt ->
     fprintf f "mt";
  | No n ->
     fprintf f "#%s" n;
  | Ms (m, p, pos, e) ->
     fprintf f "@[<2>m(";
     print_meas f m;
     fprintf f ", %s, <%s>,@ " p (show_pos pos);
     print_ev f e;
     fprintf f ")@]"
  | G (e, p) ->
     fprintf f "g(";
     print_ev f e;
     fprintf f ", %s)" p
  | H (e, p) ->
     fprintf f "h(";
     print_ev f e;
     fprintf f ", %s)" p
  | S (e1, e2) ->
     fprintf f "@[<2>s(";
     print_ev f e1;
     fprintf f ",@ ";
     print_ev f e2;
     fprintf f ")@]"
  | P (e1, e2) ->
     fprintf f "@[<2>p(";
     print_ev f e1;
     fprintf f ",@ ";
     print_ev f e2;
     fprintf f ")@]"

type node = int

type src =
  | Void
  | Node of int

(* Copland event labels *)

type label =
  | Nul of plc
  | Cpy of plc
  | Msp of plc * string * plc * string * pos
  | Sig of plc
  | Hsh of plc
  | Req of plc * plc
  | Rpy of plc * plc
  | Split of plc * dir
  | Join of plc * string

type stmt =
  | Lbl of node * label * ev
  | Prec of node * node
  | Feeds of src * node
  | Fuels of node * node

type stmts = stmt list

(* Location used to store output *)

let buf = ref ([] : stmt list)

(* Generate fresh integers used as events *)
let fresh =
  let gen = ref 0 in
  fun () ->
  let i = !gen in
  incr gen;
  i

(* Create an event and declare its label and evidence. *)
let event lbl ev =
  let n = fresh () in
  buf := Lbl (n, lbl, ev) :: !buf;
  n

(* Assert a precedence relation between two nodes when the source is
   not void. *)
let succ src dst =
  match src with
  | Void -> ()
  | Node n ->
     buf := Prec (n, dst) :: !buf

(* Assert a feeds relation between two nodes when the source is
   not void. *)
let feeds src dst =
  buf := Feeds (src, dst) :: !buf

(* Assert a fuels relation between two nodes when the source is
   not void. *)
let fuels src dst =
  buf := Fuels (src, dst) :: !buf

let ord = function
  | Seq d -> "seq", d
  | Par d -> "par", d

let seq = function
  | Seq _ -> true
  | Par _ -> false

let lft o =
  match o with
  | Seq Dup -> true
  | Seq Lft -> true
  | Par Dup -> true
  | Par Lft -> true
  | _ -> false

let rht o =
  match o with
  | Seq Dup -> true
  | Seq Rht -> true
  | Par Dup -> true
  | Par Rht -> true
  | _ -> false

(* Event labels for each type of event *)
let nul p =
  event (Nul p) Mt

let cpy p =
  event (Cpy p)

let meas p probe q target pos =
  event (Msp (p, probe, q, target, pos))

let sigg p =
  event (Sig p)

let hsh p =
  event (Hsh p)

let req p q =
  event (Req (p, q))

let rpy p q =
  event (Rpy  (p, q))

let splt p d =
  event (Split (p, d))

let join p b =
  event (Join (p, b))

(* Compile a Copland phrase into an item list.

   src is source of evidence (could be void when there is none).

   pred is the previous node (initially void, otherwise a node).
 *)
let rec comp t p pos e src prec =
  match t with
  | NUL ->
     let n = nul p in           (* Create event *)
     succ prec n;               (* Add prec relation *)
     feeds Void n;              (* Add feeds relation *)
     n
  | CPY ->
     let n = cpy p e in
     succ prec n;
     feeds src n;
     n
  | MEAS (probe, q, target) ->
     let e = eval t p pos e in
     let n = meas p probe q target pos e in
     succ prec n;
     feeds src n;
     n
  | SIG ->
     let e = eval t p pos e in
     let n = sigg p e in
     succ prec n;
     feeds src n;
     n
  | HSH ->
     let e = eval t p pos e in
     let n = hsh p e in
     succ prec n;
     feeds src n;
     n
  | AT (q, t') ->
     let n = req p q e in
     succ prec n;
     feeds src n;
     let m = comp t' q (0 :: pos) e (Node n) (Node n) in
     let e = eval t p pos e in
     let n = rpy p q e in
     succ (Node m) n;
     feeds (Node m) n;
     n
  | LN (t1, t2) ->
     let n = comp t1 p (0 :: pos) e src prec in
     let e = eval t1 p (0 :: pos) e in
     comp t2 p (1 :: pos) e (Node n) (Node n)
  | BR (o, t1, t2) ->
     let b, d = ord o in
     let n = splt p d e in
     succ prec n;
     feeds src n;
     let l = comp t1 p (0 :: pos)
               (if lft o then e else Mt)
               (if lft o then (Node n) else Void)
               (Node n) in
     let pred = if seq o then l else n in
     let r = comp t2 p (1 :: pos)
               (if lft o then e else Mt)
               (if rht o then (Node n) else Void)
               (Node pred) in
     let e = eval t p pos e in
     let n = join p b e in
     if not (seq o) then succ (Node l) n;
     succ (Node r) n;
     feeds (Node l) n;
     fuels r n;
     n

(* A simple transitive closure.  As soon as there is progress, restart
   the whole loop. *)

let rec tc_start stmts =
  tc_outer stmts stmts

(* Find a pair of nodes *)
and tc_outer stmts = function
  | [] -> stmts
  | Lbl _ :: oss -> tc_outer stmts oss
  | Prec (n1, n2) :: oss -> tc_inner stmts oss n1 n2 stmts
  | Feeds _ :: oss -> tc_outer stmts oss
  | Fuels _ :: oss -> tc_outer stmts oss

(* Try to add prec relation *)
and tc_inner stmts oss n1 n2 = function
  | [] -> tc_outer stmts oss    (* Nothing to do *)
  | Lbl _ :: iss -> tc_inner stmts oss n1 n2 iss
  | Prec (n3, n4) :: iss ->
     if n2 = n3 && not (List.mem (Prec (n1, n4)) stmts) then
       tc_start (Prec (n1, n4) :: stmts)
     else
       tc_inner stmts oss n1 n2 iss
  | Feeds _ :: iss -> tc_inner stmts oss n1 n2 iss
  | Fuels _ :: iss -> tc_inner stmts oss n1 n2 iss

(* Compute the transitive closure of the precedence relation.  Put the
   added stmts at the end of the list by performing the two reverse
   operations. *)

let tc stmts =
  List.rev @@ tc_start @@ List.rev stmts

(* Extract the nodes associated with measurement events *)
let meas_nodes stmts =
  let f ns = function
    | Lbl (n, Msp (_, _, _, _, _), _) -> n :: ns
    | _ -> ns in
  List.fold_left f [] stmts

(* Extract a measurement event semantics from some Copland events *)

let meas_events stmts =
  let ns = meas_nodes stmts in
  let f = function
    | Lbl (_, Msp (_, _, _, _, _), _) -> true
    | Lbl _ -> false
    | Prec (n1, n2) ->
       List.mem n1 ns && List.mem n2 ns
    | Feeds _ -> false
    | Fuels _ -> false in
  List.filter f @@ tc stmts

(* Generate the events and their orderings from a Copland phrase. *)

let events (p, nonce, t) =
  let e = match nonce with
    | None -> Mt
    | Some n -> No n in
  let _ = comp t p [] e Void Void in
  List.rev !buf
