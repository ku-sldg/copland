(* Command-line processing for a filter program using Getopt *)

let usage =
  Printf.sprintf
    "Usage: %s [OPTIONS] [INPUT]\n\
    Options:\n\
    \  -o FILE  --output=FILE  output to file (default is standard output)\n\
    \  -m INT   --margin=INT   set output margin\n\
    \  -v       --version      print version number\n\
    \  -h       --help         print this message"
    Sys.argv.(0)

let output  = ref ""
let version = ref false
let margin  = ref 0
let help    = ref false

let getint option place string =
  match int_of_string_opt string with
  | Some i -> place := i
  | None -> failwith ("Bad value for option " ^ option)

let specs =
[
 ('o', "output",  None, Getopt.atmost_once output
                          (Getopt.Error "only one output"));
 ('m', "margin", None, Some (getint "margin" margin));
 ('v', "version", Getopt.set version true, None);
 ('h', "help", Getopt.set help true, None);
]

let cmdline v specs =
  let args = ref [] in
  let add_arg arg = args := arg :: !args in
  (try
     Getopt.parse_cmdline specs add_arg
   with
   | Getopt.Error s ->
      prerr_endline s;
      prerr_endline "";
      prerr_endline usage;
      exit 1);
  if !help then
    begin
      print_endline usage;
      exit 0
    end
  else if !version then
    begin
      print_endline v;
      exit 0
    end
  else
    List.rev !args

let start version go =
  let (in_name, in_ch) =
    match cmdline version specs with
    | [] -> ("", stdin)
    | [f] -> (try (f, open_in f)
              with Sys_error s -> failwith s)
    | _ ->
	prerr_endline "Bad command-line argument count\n";
	prerr_endline usage;
	exit 1 in
  go !margin in_name in_ch !output

let filter version go =
  try
    start version go
  with
  | Failure s ->
      prerr_endline s;
      exit 1
