(* The copland2pos program *)

open Copland
type node = int
type src = Void | Node of int
type label =
    Nul of plc * src
  | Cpy of plc * src
  | Msp of plc * src * string * plc * string
  | Sig of plc * src
  | Hsh of plc * src
  | Req of plc * src * plc
  | Rpy of plc * node * plc
  | Split of plc * src * dir
  | Join of plc * node * node * string
type stmt = Lbl of node * label | Pos of node * int list
type stmts = stmt list
val evi_pos : copland -> stmts
