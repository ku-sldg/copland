(* Assign positions to the events of a Copland phrase *)

open Printf
open Filter
open Copland

type node = int

type src =
  | Void
  | Node of int

(* Copland event labels *)

type label =
  | Nul of plc * src
  | Cpy of plc * src
  | Msp of plc * src * string * plc * string
  | Sig of plc * src
  | Hsh of plc * src
  | Req of plc * src * plc
  | Rpy of plc * node * plc
  | Split of plc * src * dir
  | Join of plc * node * node * string

type stmt =
  | Lbl of node * label
  | Pos of node * int list

type stmts = stmt list

(* Location used to store output *)

let buf = ref ([] : stmt list)

(* Generate fresh integers used as events *)
let fresh =
  let gen = ref 0 in
  fun () ->
  let i = !gen in
  incr gen;
  i

(* Create an event and declare its label. *)
let event lbl =
  let n = fresh () in
  buf := Lbl (n, lbl) :: !buf;
  n

let ord = function
  | Seq d -> "seq", d
  | Par d -> "par", d

let lft o =
  match o with
  | Seq Dup -> true
  | Seq Lft -> true
  | Par Dup -> true
  | Par Lft -> true
  | _ -> false

let rht o =
  match o with
  | Seq Dup -> true
  | Seq Rht -> true
  | Par Dup -> true
  | Par Rht -> true
  | _ -> false

(* Event labels for each type of event *)
let nul p src =
  event (Nul (p, src))

let cpy p src =
  event (Cpy (p, src))

let meas p src probe q target =
  event (Msp (p, src, probe, q, target))

let sigg p src =
  event (Sig (p, src))

let hsh p src =
  event (Hsh (p, src))

let req p src q =
  event (Req (p, src, q))

let rpy p src q =
  event (Rpy  (p, src, q))

let split p src d =
  event (Split (p, src, d))

let join p lft rht b =
  event (Join (p, lft, rht, b))

(* Assign a position to an event *)
let pos n p =
  buf := Pos (n, List.rev p) :: !buf

(* Compile a Copland phrase into label and position statements *)
let rec comp t p src pi =
  match t with
  | NUL ->
     let n = nul p src in       (* Create event *)
     pos n pi;                  (* Add position *)
     n
  | CPY ->
     let n = cpy p src in
     pos n pi;
     n
  | MEAS (probe, q, target) ->
     let n = meas p src probe q target in
     pos n pi;
     n
  | SIG ->
     let n = sigg p src in
     pos n pi;
     n
  | HSH ->
     let n = hsh p src in
     pos n pi;
     n
  | AT (q, t') ->
     let n = req p src q in
     pos n (1 :: pi);
     let m = comp t' q (Node n) (2 :: pi) in
     let n = rpy p m q in
     pos n (3 :: pi);
     n
  | LN (t1, t2) ->
     let n = comp t1 p src (1 :: pi) in
     comp t2 p (Node n) (2 :: pi)
  | BR (o, t1, t2) ->
     let b, d = ord o in
     let n = split p src d in
     pos n (1 :: pi);
     let l = comp t1 p (if lft o then (Node n) else Void) (2 :: pi) in
     let r = comp t2 p (if rht o then (Node n) else Void) (3 :: pi) in
     let n = join p l r b in
     pos n (4 :: pi);
     n

(* Return the evidence event positions for a Copland phrase *)
let evi_pos (p, _, t) =
  let f stmt =
    match stmt with
    | Pos _ -> true
    | _ -> false
  in
  let _ = comp t p Void [] in
  List.filter f !buf

(* Show event positions *)
let show_pos o stmts =
  let f o stmt =
    match stmt with
    | Pos (n, p) ->
       fprintf o "e%d:\t" n;
       List.iter (fun d -> fprintf o " %d" d) p;
       fprintf o "\n"
    | _ -> ()
  in
  List.iter (f o) stmts

(* Main routine *)
let go ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let (p, _, t) = read_copland lexbuf in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let _ = comp t p Void [] in
  show_pos o (List.rev !buf);
  close_out o

let () =
  filter "0.1" go
