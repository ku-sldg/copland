(* The coplandsignall program *)
