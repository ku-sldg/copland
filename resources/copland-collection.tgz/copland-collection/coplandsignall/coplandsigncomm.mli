(* The coplandsigncomm program *)
