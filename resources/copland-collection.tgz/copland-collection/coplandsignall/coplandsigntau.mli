(* The coplandsigtau program *)
