(* Add signatures to a  Copland phrase *)

open Copland
open Events
open Margin

(*  Add signatures by looking at the tau function. *)

type places =
  | All
  | Set of plc list

let intersect_place plc = function
  | All -> Set [plc]
  | Set places ->
     if List.mem plc places then
       Set [plc]
     else
       Set []

let list_union left right =
  let f acc elm =
    if List.mem elm acc then
      acc
    else
      elm :: acc in
  List.fold_left f left right

let union_places set0 set1 =
  match set0, set1 with
  | All, _ -> All
  | _, All -> All
  | Set places0, Set places1 ->
     Set (list_union places0 places1)

let rec tau = function
  | Mt -> Set []
  | No _ -> Set []
  | Ms _ -> All
  | G (ev, plc) -> intersect_place plc (tau ev)
  | H (ev, _) -> tau ev
  | S (ev0, ev1) -> union_places (tau ev0) (tau ev1)
  | P (ev0, ev1) -> union_places (tau ev0) (tau ev1)

let rec sign_tau phrase plc pos ev =
  match phrase with
  | LN (x, y) ->
     let v = sign_tau x plc (0 :: pos) ev in
     LN (v, sign_tau y plc (1 :: pos) (eval v plc (0 :: pos) ev))
  | BR (Seq dir, x, y) ->
     let e1, e2 = split dir ev in
     BR (Seq dir, sign_tau x plc (0 :: pos) e1,
         sign_tau y plc (1 :: pos) e2)
  | BR (Par dir, x, y) ->
     let e1, e2 = split dir ev in
     BR (Par dir, sign_tau x plc (0 :: pos) e1,
         sign_tau y plc (1 :: pos) e2)
  | AT (p, x) when p == plc ->
     AT (p, sign_tau x p (0 :: pos) ev)
  | AT (q, x) ->
     let tau_e = tau ev in
     let tau_e_sub_p =
       match tau_e with
       | Set [] -> true
       | Set [p] when p == plc -> true
       | _ -> false in
     if tau_e_sub_p then
       let tau_eval =
         tau (eval (sign_tau x q (0 :: pos) ev) q (0 :: pos) ev) in
       let tau_eval_sub_q =
         match tau_eval with
         | Set [] -> true
         | Set [p] when p == q -> true
         | _ -> false in
       if tau_eval_sub_q then
         AT (q, sign_tau x q (0 :: pos) ev)
       else
         AT (q, LN (sign_tau x q (0 :: 0 :: pos) ev, SIG))
     else
       let tau_eval_too =
         tau (eval (sign_tau x q (0 :: pos) (G (ev, plc)))
                q (0 :: pos) (G (ev, plc))) in
       let tau_eval_sub_q =
         match tau_eval_too with
         | Set [] -> true
         | Set [p] when p == q -> true
         | _ -> false in
       if tau_eval_sub_q then
         LN (SIG, AT (q, sign_tau x q (1 :: 0 :: pos) ev))
       else
         LN (SIG, AT (q, LN (sign_tau x q (1 :: 0 :: 0 :: pos) ev, SIG)))
  | x -> x

let sign_phrase (plc, nonce, phrase) =
  let init =
    match nonce with
    | None -> Mt
    | Some x -> No x in
  plc, nonce, sign_tau phrase plc [] init

(* Main routine *)
let go margin ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let t = sign_phrase t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  if margin > 0 then
    Format.pp_set_margin f margin; (* Set margin *)
  pp_copland f t;
  close_out o

let () =
  filter "0.1" go
