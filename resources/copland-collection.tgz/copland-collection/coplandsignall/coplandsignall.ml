(* Add signatures to a  Copland phrase *)

open Copland
open Margin

(* Simplify a Copland phrase by omitting duplicate signatures.

   The simplifier has three goals:

    1. Never sign a signature.

    2. Never sign the null evidence assuming that all @ phrases
       produce something worth signing.

    3. Never sign the same evidence twice.  *)

let rec sign_null = function
  | AT (plc, x) -> AT (plc, sign_null (LN (x, SIG)))
  | LN (SIG, x) -> sign_null x
  | LN (NUL, x) -> LN (NUL, sign_null x)
  | LN (CPY, x) -> sign_null x
  | LN (LN (x, y), z) -> sign_null (LN (x, LN (y, z)))
  | LN (x, y) -> LN (sign_null x, sign_all y)
  | BR (o, x, y) -> BR (o, sign_null x, sign_null y)
  | x -> x

and sign_all = function
  | AT (plc, x) -> LN (SIG, AT (plc, sign_null (LN (x, SIG))))
  | LN (SIG, SIG) -> SIG
  | LN (SIG, x) -> LN (SIG, sign_null x)
  | LN (NUL, x) -> LN (NUL, sign_null x)
  | LN (CPY, x) -> sign_all x
  | LN (LN (x, y), z) -> sign_all (LN (x, LN (y, z)))
  | LN (x, y) -> LN (sign_all x, sign_all y)
  | BR ((Seq Nil) as o, x, y) ->
     sign_branch o (sign_null x) (sign_null y)
  | BR ((Par Nil) as o, x, y) ->
     sign_branch o (sign_null x) (sign_null y)
  | BR ((Seq Lft) as o, x, y) ->
     sign_branch o (sign_all x) (sign_null y)
  | BR ((Par Lft) as o, x, y) ->
     sign_branch o (sign_all x) (sign_null y)
  | BR ((Seq Rht) as o, x, y) ->
     sign_branch o (sign_null x) (sign_all y)
  | BR ((Par Rht) as o, x, y) ->
     sign_branch o (sign_null x) (sign_all y)
  | BR ((Seq Dup) as o, x, y) ->
     sign_branch o (sign_all x) (sign_all y)
  | BR ((Par Dup) as o, x, y) ->
     sign_branch o (sign_all x) (sign_all y)
  | x -> x

and sign_branch o x y =
  match x, y with
  | LN (SIG, x), LN (SIG, y) -> LN (SIG, BR (o, x, y))
  | LN (SIG, x), y -> LN (SIG, BR (o, x, y))
  | x, LN (SIG, y) -> LN (SIG, BR (o, x, y))
  | _ -> BR (o, x, y)

let sign_phrase (plc, nonce, phrase) =
  plc, nonce, sign_null phrase

(* Main routine *)
let go margin ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let t = sign_phrase t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  if margin > 0 then
    Format.pp_set_margin f margin; (* Set margin *)
  pp_copland f t;
  close_out o

let () =
  filter "0.1" go
