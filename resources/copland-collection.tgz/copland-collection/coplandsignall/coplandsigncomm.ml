(* Add signatures to a  Copland phrase *)

open Copland
open Margin

(* Simplify a Copland phrase by omitting duplicate signatures.

   The simplifier has two goals:

    1. Ensure all cross-place communication is signed.

    2. Never sign a signature. *)

let rec sign_comm = function
  | AT (plc, x) -> LN (SIG, AT (plc, sign_comm (LN (x, SIG))))
  | LN (LN (x, y), z) -> sign_comm (LN (x, LN (y, z)))
  | LN (SIG, x) ->
     (match sign_comm x with
      | SIG -> SIG
      | LN (SIG, y) -> LN (SIG, y)
      | y -> LN (SIG, y))
  | LN (x, y) -> LN (sign_comm x, sign_comm y)
  | BR (o, x, y) -> BR (o, sign_comm x, sign_comm y)
  | x -> x

let sign_phrase (plc, nonce, phrase) =
  plc, nonce, sign_comm phrase

(* Main routine *)
let go margin ifile i ofile =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let t = sign_phrase t in
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let f = Format.formatter_of_out_channel o in
  if margin > 0 then
    Format.pp_set_margin f margin; (* Set margin *)
  pp_copland f t;
  close_out o

let () =
  filter "0.1" go
