(* Print tamper strategies as Chase input for Copland phrases *)

open Copland
open Flow
open Plain
open Printf
open Tamper

let show_plain o stgys =
  let g o s =
    fprintf o "\n  {";
    (match s with
     | [] -> ()
     | v :: vs ->
        fprintf o "v%d" v;
        List.iter (fun v -> fprintf o ", v%d" v) vs);
    fprintf o "}" in
  let f o i = function
    | [[]] -> ()
    | ss ->
       fprintf o "v%d:" i;
       List.iter (g o) ss;
       fprintf o "\n" in
  Array.iteri (f o) stgys

let prepare_chase stgys =
  let f v = function
    | [[]] -> []
    | ss -> List.map (fun s -> (v, s)) ss in
  List.concat (Array.to_list (Array.mapi f stgys))

let show_tgts_chase o stgys =
  let f o i (v, _) =
    if i = 0 then
      fprintf o "\n  V = v%d & S = s%d" v i
    else
      fprintf o "\n  | V = v%d & S = s%d" v i in
  fprintf o "%% Tamper strategy targets\ntmpr_stgy(V, S) =>";
  (if List.length stgys = 0 then
    fprintf o " false"
  else
    List.iteri (f o) stgys);
  fprintf o ".\n"
  
let show_mems_chase o stgys =
  let f o i (vt, s) =
    match s with
    | [] -> ()
    | v :: vs ->
       fprintf o "\n%% Target v%d\n" vt;
       fprintf o "mem(v%d, s%d)" v i;
       List.iter (fun v -> fprintf o " & mem(v%d, s%d)" v i) vs;
       fprintf o ".\n";
       fprintf o "mem(V, s%d) => V = v%d" i v;
       List.iter (fun v -> fprintf o " | V = v%d" v) vs;
       fprintf o ".\n" in
  List.iteri (f o) stgys
  
let show_chase o stgys =
  let stgys = prepare_chase stgys in
  show_tgts_chase o stgys;
  show_mems_chase o stgys

(* Main routine *)
let go ifile i ofile chase =
  let lexbuf = read_lexbuf ifile i in
  let t = read_copland lexbuf in
  close_in i;
  let o =                       (* Open output *)
    if ofile = "" then
      stdout
    else
      open_out ofile in
  let stgys = meas_stgys (data_flow t) in
  (if chase then
     show_chase o stgys
   else
     show_plain o stgys);
  close_out o
  
let () =
  plain "0.1" go
