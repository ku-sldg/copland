(* The copland2tmpr program *)
