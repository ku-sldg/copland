val plain : string -> (string -> in_channel -> string -> bool -> unit) -> unit
