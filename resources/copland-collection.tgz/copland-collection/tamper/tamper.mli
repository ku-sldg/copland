open Events
open Flow

type tmpr_stgy = node list

val meas_stgys : flow_graph -> tmpr_stgy list array
