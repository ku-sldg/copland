(* Compute tamper strategies for Copland phrases *)

open Copland
open Events
open Flow

module Path =
  struct
    type t = int list
    let rec compare xs ys =
      match xs, ys with
      | [], [] -> 0
      | [], _ :: _ -> -1
      | _ :: _ , [] -> 1
      | x :: xs, y :: ys ->
         match Stdlib.compare x y with
         | 0 -> compare xs ys
         | c -> c
  end

module PathSet = Set.Make(Path)

(* Identifies where tampering is permitted along a path *)
type tmpr_at =
  | Any
  | At of plc

type tmpr_stgy = node list

(* Get the top node of a data flow graph *)
let top graph = graph.(Array.length graph - 1)

(* Return the place projection of a label *)
let projp = function
  | Nul p -> p
  | Cpy p -> p
  | Msp (p, _, _, _, _) -> p
  | Sig p -> p
  | Hsh p -> p
  | Req (p, _) -> p
  | Rpy (p, _) -> p
  | Split (p, _) -> p
  | Join (p, _) -> p

(* Return the dual place projection of a label *)
let dprojp label =
  match label with
  | Req (_, q) -> q
  | Rpy (_, q) -> q
  | _ -> projp label

(* Compute accumulating paths to top *)
let paths2top graph =
  let top = top graph in
  let rec f v ps =
    let s_v = graph.(v).src in
    let p_v = PathSet.filter (fun p -> List.hd p = v) ps in
    let g ps' v' =
      f v' (PathSet.union ps' (PathSet.map (List.cons v') p_v)) in
    List.fold_left g ps s_v in
  PathSet.elements (f top.node (PathSet.singleton [top.node]))

(* Extract paths to top starting with tamperable measurement events *)
let meas_paths2top graph =
  let ps = paths2top graph in
  let p_top = projp (top graph).lbl in
  let f node =
    match node.lbl with
    | Msp (p, _, _, _, _) when p != p_top  ->
       List.filter (fun p -> List.hd p = node.node) ps
    | _ -> [] in
  Array.map f graph

(* Compute pathwise tamperers for tamperable measurement events *)
let meas_tmprs graph =
  let p_top = projp (top graph).lbl in
  let rec f at = function
    | [] -> []
    | v :: vs ->
       let l = graph.(v).lbl in
       let near_top =
         projp l = p_top || dprojp l = p_top in
       match (at, l) with
       | (Any, Sig p) ->
          v :: if near_top then [] else f (At p) vs
       | (At q, Sig p) when p != q -> []
       | (Any, _) ->
          v :: if near_top then [] else f at vs
       | (At q, _) ->
          if projp l = q || dprojp l = q then
            v :: if near_top then [] else f at vs
          else
            if near_top then [] else f at vs in
  let g p = f Any (List.tl p) in
  Array.map (List.map g) (meas_paths2top graph)

(* Compute the Cartesian product of a collection of sets *)
let cart_prod ss =
  let rec f acc = function
    | [] -> acc
    | s :: ss ->
       let acc' =
         List.concat_map (fun x -> List.map (List.cons x) acc) s in
       f acc' ss in
  f [[]] (List.rev ss)

(* Reduce a collection of sets to its minimal members *)
let minimize ss =
  let is_proper_subset s s' =
    List.length s < List.length s'
    && List.fold_left (&&) true (List.map (fun x -> List.mem x s') s) in
  let supersets ss s = List.filter (is_proper_subset s) ss in
  let rdndts = List.concat_map (supersets ss) ss in
  List.filter (fun x -> not (List.mem x rdndts)) ss

(* Compute minimal tamper strategies for measurement events *)
let meas_stgys graph =
  let cart_fact tmprs = List.map (List.sort_uniq compare) (cart_prod tmprs) in
  let stgys tmprs = List.sort_uniq compare (cart_fact tmprs) in
  let min_stgys tmprs = minimize (stgys tmprs) in
  Array.map min_stgys (meas_tmprs graph)
