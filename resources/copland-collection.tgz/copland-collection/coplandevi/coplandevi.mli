(* The coplandevi program *)
