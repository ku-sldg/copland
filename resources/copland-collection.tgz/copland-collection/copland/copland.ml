(* Copland abstract syntax *)

open Lexing
open Format
open Message

include Copland_type

let read_lexbuf fname ch =
  if Filename.check_suffix fname ".md" then
    Markdown.read_lexbuf fname ch
  else
    let lexbuf = from_channel ch in
    lexbuf.lex_curr_p <- { lexbuf.lex_curr_p with pos_fname = fname };
    lexbuf

let read_copland lexbuf =
  try
    Parser.file Scanner.token lexbuf
  with
  | Parsing.Parse_error ->
     parse_err (lexeme_start_p lexbuf) "Syntax error"

let error_msg = error_msg

let failwith_msg pos msg =
  failwith (error_msg pos msg)

let print_meas f (asp, p, target) =
  fprintf f "ms(%s, %s, %s)" asp p target

let open_par f =
  pp_print_string f "(";
  pp_open_box f 0

let close_par f =
  pp_print_string f ")";
  pp_close_box f ()

let order = function
  | Seq Dup -> "+<+"
  | Seq Lft -> "+<-"
  | Seq Rht -> "-<+"
  | Seq Nil -> "-<-"
  | Par Dup -> "+~+"
  | Par Lft -> "+~-"
  | Par Rht -> "-~+"
  | Par Nil -> "-~-"

(* Pretty print a Copland phrase *)

(* Variable par is true when branches should be parenthesized.
   Variable brk is true when at's should use brackets. *)
let rec pp_term f par brk = function
  | NUL ->
     pp_print_string f "{}"
  | CPY ->
     pp_print_string f "_"
  | MEAS (asp, q, target) ->
     fprintf f "%s %s %s" asp q target
  | SIG ->
     pp_print_string f "!"
  | HSH ->
     pp_print_string f "#"
  | AT (p, t) ->
     if brk then
       begin
         fprintf f "%@%s [@[" p;
         pp_term f false false t;
         fprintf f "@]]"
       end
     else
       begin
         fprintf f "%@%s @[" p;
         pp_term f false false t;
         fprintf f "@]"
       end
  | LN (t1, t2) ->
     pp_term f true true t1;
     fprintf f "@ -> ";
     pp_term f true brk t2;
  | BR (ord, t1, t2) ->
     if par then
       open_par f;
     pp_term f true true t1;
     fprintf f "@ %s " (order ord);
     pp_term f true (not par && brk) t2;
     if par then
       close_par f

let pp_copland f (p, n, t) =
  pp_open_box f 2;
  fprintf f "*%s" p;
  (match n with
   | None -> ()
   | Some no ->
      fprintf f ", %s" no);
  fprintf f ":@ ";
  pp_term f false false t;
  pp_close_box f ();
  pp_print_newline f ()
