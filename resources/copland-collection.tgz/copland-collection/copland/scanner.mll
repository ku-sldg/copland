(* Lexical analysis of copland input *)

{
open Parser
open Lexing
open Copland_type
}

let start = ['a' - 'z' 'A' - 'Z']
let part = start | ['_' '0' - '9']
rule token = parse
    [' ' '\t']		{ token lexbuf }
  | '\n'		{ new_line lexbuf; token lexbuf }
  | '%' [^ '\n']*	{ token lexbuf }
  | '*'                 { TAST }
  | ':'                 { TCOL }
  | ','                 { TCOM }
  | "{}"                { TNUL }
  | '_'                 { TCPY }
  | '!'                 { TSIG }
  | '#'                 { THSH }
  | '@'                 { TAT }
  | "->"                { TLN }
  | "+<+"               { TBR (Seq Dup) }
  | "+<-"               { TBR (Seq Lft) }
  | "-<+"               { TBR (Seq Rht) }
  | "-<-"               { TBR (Seq Nil) }
  | "+~+"               { TBR (Par Dup) }
  | "+~-"               { TBR (Par Lft) }
  | "-~+"               { TBR (Par Rht) }
  | "-~-"               { TBR (Par Nil) }
  | '('                 { LPAR }
  | ')'                 { RPAR }
  | '['                 { LBRA }
  | ']'                 { RBRA }
  | ['0' - '9']+ as s   { PLACE ("p" ^ s) }
  | start part* as s    { SYMBOL s }
  | eof                 { EOF }
  | _			{ raise Parsing.Parse_error }
