/* Grammar for copland input */

%token TNUL TCPY TSIG THSH
%token TAT LPAR RPAR LBRA RBRA TAST TCOL TCOM
%token TLN
%token <Copland_type.order> TBR
%token <string> PLACE
%token <string> SYMBOL
%token EOF
%nonassoc TAT
%nonassoc TBR
%right TLN
%start file
%type <Copland_type.copland> file
%%

file:
   copland EOF { $1 }

copland:
   phrase                          { "p0", None, $1 }
 | TAST place nonce TCOL phrase    { $2, $3, $5 }

place:
   SYMBOL                          { $1 }
 | PLACE                           { $1 }

nonce:
  /* empty */                      { None }
  | TCOM SYMBOL                    { Some $2 }

phrase:
   TNUL                            { NUL }
 | TCPY                            { CPY }
 | SYMBOL place SYMBOL             { MEAS ($1, $2, $3) }
 | TSIG                            { SIG }
 | THSH                            { HSH }
 | TAT place phrase %prec TAT      { AT ($2, $3) }
 | TAT place LBRA phrase RBRA      { AT ($2, $4) }
 | phrase TLN phrase               { LN ($1, $3) }
 | phrase TBR phrase               { BR ($2, $1, $3) }
 | LPAR phrase RPAR                { $2 }
