(* Copland abstract syntax *)

type plc = string

type nonce = string

type meas = string * plc * string

type dir =                      (* Evidence flow in *)
  | Dup                         (* a branch *)
  | Lft
  | Rht
  | Nil

type order =                    (* Ordering among branches *)
  | Seq of dir
  | Par of dir

type phrase =                   (* Kinds of phrases *)
  | NUL
  | CPY
  | MEAS of meas
  | SIG
  | HSH
  | AT of plc * phrase
  | LN of phrase * phrase
  | BR of order * phrase * phrase

(* Starting place, possible starting nonce, and a phrase *)
type copland = plc * nonce option * phrase
