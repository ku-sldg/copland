open Lexing
type plc = string
type nonce = string
type meas = string * plc * string
type dir = Dup | Lft | Rht | Nil
type order = Seq of dir | Par of dir
type phrase =
  | NUL
  | CPY
  | MEAS of meas
  | SIG
  | HSH
  | AT of plc * phrase
  | LN of phrase * phrase
  | BR of order * phrase * phrase
type copland = plc * nonce option * phrase
val read_lexbuf : string -> in_channel -> lexbuf
val read_copland : lexbuf -> copland
val error_msg : position -> string -> string
val failwith_msg : position -> string -> 'a
val print_meas : Format.formatter -> meas -> unit
val pp_copland : Format.formatter -> copland -> unit
