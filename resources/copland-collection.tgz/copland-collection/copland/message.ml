(* Parse input and convert it into formulas *)

open Lexing

let pos_info pos =
  pos.pos_fname, pos.pos_lnum, pos.pos_cnum - pos.pos_bol + 1

let error_msg pos msg =
  let fname, lnum, cnum = pos_info pos in
  Printf.sprintf "%s:%d:%d: %s" fname lnum cnum msg

let parse_err pos msg =
  failwith (error_msg pos msg)
