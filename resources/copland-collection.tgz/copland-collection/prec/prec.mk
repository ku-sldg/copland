# Makefile rules for prec

# Run chase for prec
%.prec:		%.gl
	chase -tcs $(PRECCHASEFLAGS) -o $@ $*.gl

%.svg:		%.prec
	prec $(PRECFLAGS) $*.prec | tred | dot -Tsvg -o $@
