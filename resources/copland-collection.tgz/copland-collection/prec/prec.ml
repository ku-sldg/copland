(* Generates a Graphviz dot source that shows the event semantics of a
   Copland phrase.  A typical usage is:

   $ chase -tsc file.gl | prec | tred | dot -Tsvg > file.svg

   The events semantics is specified by a model that has at least two
   types of facts, facts about event labels, and facts about the
   ordering of events.  An event label fact is of the form:

   l(E) = L,

   where E is an event and L is its label.  The ordering of two events
   is expressed as a fact of the form:

   prec(E1, E1),

   where E1 and E2 are events.

   The tred program computes the transitive reduction, and is only
   needed when the theory given to Chase includes an axiom that
   asserts that prec is transitive.

   Use the compact option (prec -c) to produce an event semantics that
   only shows events related to a measurement (msp, cor, and rep).
   This option should only be used when the theory includes an axiom
   that asserts that prec is transitive.  *)

open Sexpr
open Main

(* Create a label for a node storing the string into a buffer *)
let rec term buf = function
  | S (_, sym) ->
     Buffer.add_string buf sym
  | L (_, S (_, sym) :: arg :: args) ->
     Buffer.add_string buf sym;
     Buffer.add_string buf "(";
     term buf arg;
     terms buf args
  | _ -> assert false

and terms buf = function
  | [] ->
     Buffer.add_string buf ")"
  | arg :: args ->
     Buffer.add_string buf ", ";
     term buf arg;
     terms buf args

(* Create a label for a node *)
let label x =
  let buf = Buffer.create 32 in
  term buf x;
  Buffer.contents buf

(* Generate a fresh node *)
let gen_node =
  let counter = ref 0 in
  fun () ->
  let s = Printf.sprintf "n%d" !counter in
  incr counter;
  s

(* Find a graph node by its event and create a new node if it is not
   in the table. *)
let find_node tbl event =
  match Hashtbl.find_opt tbl event with
  | Some node -> node
  | None ->
     let node = gen_node () in
     Hashtbl.add tbl event node;
     node

let find_lab labs event =
  match Hashtbl.find_opt labs event with
  | Some lab -> lab
  | None -> event

(* Add labels to the table *)
let l nodes labs = function
  | L (_, [S (_, "="); (* Ignore equalities between l applications *)
           L (_, [S(_, "l"); S(_, _)]); (* for now, but see l_eq *)
           L (_, [S(_, "l"); S(_, _)])]) ->
     ()
  | L (_, [S (_, "="); L (_, [S(_, "l"); S(_, left)]); right]) ->
     let _ = find_node nodes left in
     Hashtbl.replace labs left (label right)
  | L (pos, [S (_, "="); L (_, [S(_, "l"); _]); _]) ->
     failwith_msg pos "Bad l: expecting (= (l SYMBOL) S-EXPR)"
  | L (_, [S (_, "="); right; L (_, [S(_, "l"); S(_, left)])]) ->
     let _ = find_node nodes left in
     Hashtbl.replace labs left (label right)
  | L (pos, [S (_, "="); _; L (_, [S(_, "l"); _])]) ->
     failwith_msg pos "Bad l: expecting (= S-EXPR (et SYMBOL))"
  | _ -> ()

(* Handle case in which event types are equated *)
let l_eq labs = function
  | L (_, [S (_, "=");
           L (_, [S(_, "l"); S(_, left)]);
           L (_, [S(_, "l"); S(_, right)])]) ->
     (match Hashtbl.find_opt labs left with
      | Some lab ->
         Hashtbl.replace labs right lab
      | None ->
         match Hashtbl.find_opt labs right with
         | Some lab ->
            Hashtbl.replace labs left lab
         | None -> ())            (* Both have no labels *)
  | _ -> ()

(* Get lead function symbol *)
let funsym s =
  match String.index_opt s '(' with
  | None -> s
  | Some i -> String.sub s 0 i

let is_meas_evt labs event =
  let lab = find_lab labs event in
  match funsym lab with
   | "msp" -> true
   | "cor" -> true
   | "rep" -> true
   | _ -> false

(* Remove non-measurement events from the node table *)
let strip_non_meas nodes labs =
  let f event node =
    if is_meas_evt labs event then
      Some node
    else
      None in
  Hashtbl.filter_map_inplace f nodes

(* Print a node and its label. *)
let print_node o labs event node =
  let lab = find_lab labs event in
  Printf.fprintf o "  %s [label = \"%s\"" node lab;
  (match funsym lab with
   | "msp" -> output_string o ", shape=box, color=blue"
   | "cor" -> output_string o ", shape=octagon, color=red"
   | "rep" -> output_string o ", shape=hexagon, color=green3"
   | _ -> ());
  output_string o "];\n"

(* Print tamper facts in a model. *)
let print_tamper o nodes = function
  | L (_, [S (_, "tamper_node"); S(_, event)]) ->
     Printf.fprintf o "  %s [shape=house];\n" (find_node nodes event)
  | L (pos, [S (_, "tamper_node"); _]) ->
     failwith_msg pos "Bad tamper_node: expecting (tamper_node SYMBOL)"
  | L (_, [S (_, "detects"); S (_, event)]) ->
     Printf.fprintf o "  %s [shape=invhouse];\n" (find_node nodes event)
  | L (pos, [S (_, "detects"); _]) ->
     failwith_msg pos "Bad detects: expecting (detects SYMBOL)"
  | _ -> ()

(* Print prec facts in a model. *)
let print_prec o nodes = function
  | L (_, [S (_, "prec"); S (_, left); S(_, right)]) ->
     (match Hashtbl.find_opt nodes left with
      | None -> ()
      | Some left ->
         match Hashtbl.find_opt nodes right with
         | None -> ()
         | Some right ->
            Printf.fprintf o "  %s -> %s;\n" left right)
  | L (pos, [S (_, "prec"); _; _]) ->
     failwith_msg pos "Bad prec: expecting (prec SYMBOL SYMBOL)"
  | _ -> ()

(* Print one model *)
let model compact o = function
  | L (_, S (_, _) :: xs) ->
     let facts = assoc "facts" xs in
     let nodes = Hashtbl.create 100 in (* events -> nodes *)
     let labs = Hashtbl.create 100 in (* events -> labels *)
     (* Add nodes and labels for nodes into labs table *)
     List.iter (l nodes labs) facts;
     List.iter (l_eq labs) facts;
     (* Strip non-measurement events with compact option *)
     if compact then strip_non_meas nodes labs;
     (* Print nodes *)
     Hashtbl.iter (print_node o labs) nodes;
     List.iter (print_tamper o nodes) facts;
     (* Print edges *)
     List.iter (print_prec o nodes) facts
  | _ -> ()

let run compact o xs =
  output_string o "digraph G {\n";
  List.iter (model compact o) xs;
  output_string o "}\n"

let () =
  main run
