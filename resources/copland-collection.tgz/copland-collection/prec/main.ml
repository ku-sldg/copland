(* Main entry point *)

let version_number = "0.2"

open Sexpr

let read_sexprs ch =
  let rec loop xs =
    try
      let x = read_sexpr ch in
      loop (x :: xs)
    with
    | End_of_file ->
	List.rev xs in
  loop []

let go run compact f i ofile =
  let lb = read_lexbuf f i in
  let xs = read_sexprs lb in
  close_in i;
  let o =
    if ofile = "" then
      stdout
    else
      open_out ofile in
  run compact o xs

(* Command-line processing for a filter program using Getopt *)

let usage =
  Printf.sprintf
    "Usage: %s [OPTIONS] [INPUT]\n\
    Options:\n\
    \  -o FILE  --output=FILE  output to file (default is standard output)\n\
    \  -c       --compact      show only measurement related events\n\
    \  -v       --version      print version number\n\
    \  -h       --help         print this message"
    Sys.argv.(0)

let output  = ref ""
let compact  = ref false
let version = ref false
let help    = ref false

let specs =
[('o', "output",  None, Getopt.atmost_once output
                          (Getopt.Error "only one output"));
 ('c', "compact", Getopt.set compact true, None);
 ('v', "version", Getopt.set version true, None);
 ('h', "help", Getopt.set help true, None);
]

let cmdline v specs =
  let args = ref [] in
  let add_arg arg = args := arg :: !args in
  (try
     Getopt.parse_cmdline specs add_arg
   with
   | Getopt.Error s ->
      prerr_endline s;
      prerr_endline "";
      prerr_endline usage;
      exit 1);
  if !help then
    begin
      print_endline usage;
      exit 0
    end
  else if !version then
    begin
      print_endline v;
      exit 0
    end
  else
    List.rev !args

let start run =
  let (in_name, in_ch) =
    match cmdline version_number specs with
    | [] -> ("", stdin)
    | [f] -> (try (f, open_in f)
              with Sys_error s -> failwith s)
    | _ ->
	prerr_endline "Bad command-line argument count\n";
	prerr_endline usage;
	exit 1 in
  go run !compact in_name in_ch !output

let main run =
  try
    start run
  with
  | Failure s ->
      prerr_endline s;
      exit 1
